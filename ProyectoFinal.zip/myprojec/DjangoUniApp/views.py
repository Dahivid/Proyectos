from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse
@csrf_exempt
# Esto es una vista
def bienvenida(request):
    return HttpResponse("Bienvenido")


def enviar_mensaje(request):
    if request.method == 'POST':
        message = request.POST.get('message')

        # Realizar alg�n procesamiento o l�gica con el mensaje aqu�
        # ...

        # Retornar una respuesta en formato JSON
        response = {
            'message': 'Mensaje recibido por Django',
        }
        return JsonResponse(response)
