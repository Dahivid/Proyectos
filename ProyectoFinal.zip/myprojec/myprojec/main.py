# -*- coding: utf-8 -*-
"""
@author: santi
"""

from myprojec import RespuestasClase
from myprojec import KeyWordsClass
from myprojec import FuncionCoincidencias
import numpy as np
KeyWord = KeyWordsClass.KeyWords()
Respuestas = RespuestasClase.Respuestas()
#Se hará un nivel de fortaleza entre las palabras clave
#donde si la cantidad de coincidencias es igual al numero
#de palabras clave, es muy fuerte lo que significa que
#esa es la pregunta.
respuesta = str()
NumPregunta = int()
print("--> Hola, estoy aqui para ayudarte, resolvere tus dudas sobre estructuras de datos\n")

def RegNumPreg(Pregunta):
    bandera = True
    #Pregunta 1
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys1, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys1)) & (not("tipos" in Pregunta.lower())) & (not("modelos" in Pregunta.lower())) & (not("origen" in Pregunta.lower())) & (not("procedencia" in Pregunta.lower())) & (not("ejemplo" in Pregunta.lower())) & (not("caso" in Pregunta.lower())) & (not("implementar" in Pregunta.lower())) & (not("usar" in Pregunta.lower())) & (not("crear" in Pregunta.lower())) & (not("arreglos" in Pregunta.lower()))& (not("listas" in Pregunta.lower()))& (not("lista" in Pregunta.lower()))& (not("dinamica" in Pregunta.lower()))& (not("dinámica" in Pregunta.lower()))& (not("genealogico" in Pregunta.lower()))& (not("genealógico" in Pregunta.lower()))& (not("familiar" in Pregunta.lower()))& (not("recursiva" in Pregunta.lower()))& (not("recursividad" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 1
            bandera = False
        elif((len(lista_coincidencias) == (len(KeyWord.keys1)-1)) & (not("tipos" in Pregunta.lower())) & (not("modelos" in Pregunta.lower())) & (not("origen" in Pregunta.lower())) & (not("procedencia" in Pregunta.lower())) & (not("ejemplo" in Pregunta.lower())) & (not("caso" in Pregunta.lower())) & (not("implementar" in Pregunta.lower())) & (not("usar" in Pregunta.lower())) & (not("crear" in Pregunta.lower()))& (not("arreglos" in Pregunta.lower()))& (not("listas" in Pregunta.lower()))& (not("lista" in Pregunta.lower()))& (not("dinamica" in Pregunta.lower()))& (not("dinámica" in Pregunta.lower()))& (not("genealogico" in Pregunta.lower()))& (not("genealógico" in Pregunta.lower()))& (not("familiar" in Pregunta.lower()))& (not("recursiva" in Pregunta.lower()))& (not("recursividad" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 1
            bandera = False
            
    #pregunta 2
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys2, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys2)) & (not("origen" in Pregunta.lower())) & (not("procedencia" in Pregunta.lower())) & (not("ejemplo" in Pregunta.lower())) & (not("caso" in Pregunta.lower()))& (not("arreglos" in Pregunta.lower()))& (not("dinamica" in Pregunta.lower()))& (not("dinámica" in Pregunta.lower()))& (not("recursiva" in Pregunta.lower()))& (not("recursividad" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 2
            bandera = False
        elif((len(lista_coincidencias) == (len(KeyWord.keys2)-1)) & (not("origen" in Pregunta.lower())) & (not("procedencia" in Pregunta.lower())) & (not("ejemplo" in Pregunta.lower())) & (not("caso" in Pregunta.lower()))& (not("arreglos" in Pregunta.lower()))& (not("dinamica" in Pregunta.lower()))& (not("dinámica" in Pregunta.lower()))& (not("recursiva" in Pregunta.lower()))& (not("recursividad" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 2
            bandera = False      
        
    #Pregunta 3
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys3, Pregunta)
        if(len(lista_coincidencias) == len(KeyWord.keys3)):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 3
            bandera = False
            
    #Pregunta 4
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys4, Pregunta)
        if(len(lista_coincidencias) == len(KeyWord.keys4)):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 4
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys4)-1))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 4
            bandera = False
    
    #Pregunta 5
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys5, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys5))& (not("arreglo" in Pregunta.lower()))& (not("arreglos" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 5
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys5)-1))& (not("arreglo" in Pregunta.lower()))& (not("arreglos" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 5
            bandera = False
    
    #Pregunta 6
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys6, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys6))& (not("listas" in Pregunta.lower()))& (not("lista" in Pregunta.lower()))& (not("pilas" in Pregunta.lower()))& (not("pila" in Pregunta.lower()))& (not("colas" in Pregunta.lower()))& (not("cola" in Pregunta.lower()))& (not("arboles" in Pregunta.lower()))& (not("árboles" in Pregunta.lower()))& (not("grafo" in Pregunta.lower()))& (not("grafos" in Pregunta.lower()))& (not("hash" in Pregunta.lower()))& (not("tablas" in Pregunta.lower()))& (not("diferencia" in Pregunta.lower()))& (not("diferencias" in Pregunta.lower()))& (not("distinguen" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 6
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys6)-1))& (not("listas" in Pregunta.lower()))& (not("lista" in Pregunta.lower()))& (not("pilas" in Pregunta.lower()))& (not("pila" in Pregunta.lower()))& (not("colas" in Pregunta.lower()))& (not("cola" in Pregunta.lower()))& (not("arboles" in Pregunta.lower()))& (not("árboles" in Pregunta.lower()))& (not("grafo" in Pregunta.lower()))& (not("grafos" in Pregunta.lower()))& (not("hash" in Pregunta.lower()))& (not("tablas" in Pregunta.lower()))& (not("diferencia" in Pregunta.lower()))& (not("diferencias" in Pregunta.lower()))& (not("distinguen" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 6
            bandera = False
    
    #Pregunta 7
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys7, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys7))& (not("pilas" in Pregunta.lower()))& (not("pila" in Pregunta.lower()))& (not("colas" in Pregunta.lower()))& (not("cola" in Pregunta.lower()))& (not("arboles" in Pregunta.lower()))& (not("árboles" in Pregunta.lower()))& (not("grafo" in Pregunta.lower()))& (not("grafos" in Pregunta.lower()))& (not("hash" in Pregunta.lower()))& (not("tablas" in Pregunta.lower()))& (not("diferencia" in Pregunta.lower()))& (not("diferencias" in Pregunta.lower()))& (not("distinguen" in Pregunta.lower()))& (not("tiempo" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 7
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys7)-1))& (not("pilas" in Pregunta.lower()))& (not("pila" in Pregunta.lower()))& (not("colas" in Pregunta.lower()))& (not("cola" in Pregunta.lower()))& (not("arboles" in Pregunta.lower()))& (not("árboles" in Pregunta.lower()))& (not("grafo" in Pregunta.lower()))& (not("grafos" in Pregunta.lower()))& (not("hash" in Pregunta.lower()))& (not("tablas" in Pregunta.lower()))& (not("diferencia" in Pregunta.lower()))& (not("diferencias" in Pregunta.lower()))& (not("distinguen" in Pregunta.lower()))& (not("tiempo" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 7
            bandera = False
            
    #Pregunta 8
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys8, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys8))& (not("colas" in Pregunta.lower()))& (not("cola" in Pregunta.lower()))& (not("arboles" in Pregunta.lower()))& (not("árboles" in Pregunta.lower()))& (not("grafo" in Pregunta.lower()))& (not("grafos" in Pregunta.lower()))& (not("hash" in Pregunta.lower()))& (not("tablas" in Pregunta.lower()))& (not("diferencia" in Pregunta.lower()))& (not("diferencias" in Pregunta.lower()))& (not("distinguen" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 8
            bandera = False    
            
    #Pregunta 9
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys9, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys9))& (not("arboles" in Pregunta.lower()))& (not("árboles" in Pregunta.lower()))& (not("grafo" in Pregunta.lower()))& (not("grafos" in Pregunta.lower()))& (not("hash" in Pregunta.lower()))& (not("tablas" in Pregunta.lower()))& (not("diferencia" in Pregunta.lower()))& (not("diferencias" in Pregunta.lower()))& (not("distinguen" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 9
            bandera = False    
            
    #Pregunta 10
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys10, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys10))& (not("grafo" in Pregunta.lower()))& (not("grafos" in Pregunta.lower()))& (not("hash" in Pregunta.lower()))& (not("tablas" in Pregunta.lower()))& (not("avl" in Pregunta.lower()))& (not("binario" in Pregunta.lower()))& (not("genealogico" in Pregunta.lower()))& (not("genealógico" in Pregunta.lower()))& (not("familiar" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 10
            bandera = False    
            
    #Pregunta 11
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys11, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys11))& (not("hash" in Pregunta.lower()))& (not("tablas" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 11
            bandera = False
            
    #Pregunta 12
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys12, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys12))& (not("busqueda" in Pregunta.lower()))& (not("búsqueda" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 12
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys12)-1))& (not("busqueda" in Pregunta.lower()))& (not("búsqueda" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 12
            bandera = False
            
    #Pregunta 13
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys13, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys13))& (not("binario" in Pregunta.lower()))& (not("busqueda" in Pregunta.lower()))& (not("búsqueda" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 13
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys13)-1))& (not("binario" in Pregunta.lower()))& (not("busqueda" in Pregunta.lower()))& (not("búsqueda" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 13
            bandera = False
            
    #Pregunta 14
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys14, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys14))& (not("recursiva" in Pregunta.lower()))& (not("recursividad" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 14
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys14)-1))& (not("recursiva" in Pregunta.lower()))& (not("recursividad" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 14
            bandera = False
            
    #Pregunta 15
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys15, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys15))& (not("inserción" in Pregunta.lower()))& (not("eliminación" in Pregunta.lower()))& (not("insercion" in Pregunta.lower()))& (not("eliminacion" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 15
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys15)-1))& (not("inserción" in Pregunta.lower()))& (not("eliminación" in Pregunta.lower()))& (not("insercion" in Pregunta.lower()))& (not("eliminacion" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 15
            bandera = False
            
    #Pregunta 16
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys16, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys16))& (not("binario" in Pregunta.lower()))& (not("busqueda" in Pregunta.lower()))& (not("búsqueda" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 16
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys16)-1))& (not("binario" in Pregunta.lower()))& (not("busqueda" in Pregunta.lower()))& (not("búsqueda" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 16
            bandera = False
            
    #Pregunta 17
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys17, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys17)+2) | (len(lista_coincidencias) == len(KeyWord.keys17))& (not("complejidad" in Pregunta.lower()))& (not("dificultad" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 17
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys17)+1)) | (len(lista_coincidencias) == len(KeyWord.keys17)-1)& (not("complejidad" in Pregunta.lower()))& (not("dificultad" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 17
            bandera = False
            
    #Pregunta 18
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys18, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys18))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 18
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys18)-1))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 18
            bandera = False
            
    #Pregunta 19
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys19, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys19))& (not("complejidad" in Pregunta.lower()))& (not("dificultad" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 19
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys19)-1))& (not("complejidad" in Pregunta.lower()))& (not("dificultad" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 19
            bandera = False
            
    #Pregunta 20
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys20, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys20))& (not("push" in Pregunta.lower()))& (not("pop" in Pregunta.lower()))& (not("inserción" in Pregunta.lower()))& (not("eliminación" in Pregunta.lower()))& (not("insercion" in Pregunta.lower()))& (not("eliminacion" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 20
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys20)-1))& (not("push" in Pregunta.lower()))& (not("pop" in Pregunta.lower()))& (not("inserción" in Pregunta.lower()))& (not("eliminación" in Pregunta.lower()))& (not("insercion" in Pregunta.lower()))& (not("eliminacion" in Pregunta.lower()))& (not("hacer" in Pregunta.lower()))& (not("crear" in Pregunta.lower()))& (not("diseñar" in Pregunta.lower()))& (not("programar" in Pregunta.lower()))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 20
            bandera = False
            
    #Pregunta 21
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys21, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys21))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 21
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys21)-1))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 21
            bandera = False
    
    #Pregunta 22
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys22, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys22))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 22
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys22)-1))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 22
            bandera = False
    
    #Pregunta 23
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys23, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys23))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 23
            bandera = False
            
    #Pregunta 24
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys24, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys24))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 24
            bandera = False    
        elif((len(lista_coincidencias) == (len(KeyWord.keys24)-1))):
            respuesta = "Creo que la respuesta a tu pregunta es \n"
            NumPregunta = 24
            bandera = False
            
    #Pregunta 25
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys25, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys25))& (not("lista" in Pregunta.lower()))& (not("listas" in Pregunta.lower()))& (not("pila" in Pregunta.lower()))& (not("pilas" in Pregunta.lower()))& (not("cola" in Pregunta.lower()))& (not("colas" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 25
            bandera = False    
            
    #Pregunta 26
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys26, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys26))& (not("pila" in Pregunta.lower()))& (not("pilas" in Pregunta.lower()))& (not("cola" in Pregunta.lower()))& (not("colas" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 26
            bandera = False    
    
    #Pregunta 27
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys27, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys27))& (not("cola" in Pregunta.lower()))& (not("colas" in Pregunta.lower()))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 27
            bandera = False    
    
    #Pregunta 28
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys28, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys28))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 28
            bandera = False  
    
    #Pregunta 29
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys29, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys29))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 29
            bandera = False 
            
    #Pregunta 30
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys30, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys30))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 30
            bandera = False 
            
    #Pregunta 31
    if(bandera):
        lista_coincidencias = []
        lista_coincidencias = FuncionCoincidencias.ListaCoincidencias(KeyWord.keys31, Pregunta)
        if((len(lista_coincidencias) == len(KeyWord.keys31))):
            respuesta = "La respuesta a tu pregunta es \n"
            NumPregunta = 31
            bandera = False 
            
            
    return NumPregunta



def main(pregunta):
    #Segun la pregunta mostrara un resultado diferente
    try:
        repeat = True
        while(repeat):
            if(("Salir" in pregunta) | ("salir" in pregunta) | ("SALIR" in pregunta) | ("finalizar" in pregunta) |("Finalizar" in pregunta) | ("FINALIZAR" in pregunta)):
                break
            respuesta = ""
            NumeroPregunta = RegNumPreg(pregunta)
            
            if NumeroPregunta == 1: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas1[ans]
                print(respuesta)
                
            if NumeroPregunta == 2: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas2[ans]
                print(respuesta)
                
            if NumeroPregunta == 3: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas3[ans]
                print(respuesta)
            if NumeroPregunta == 4: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas4[ans]
                print(respuesta)
            if NumeroPregunta == 5: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas5[ans]
                print(respuesta)
            if NumeroPregunta == 6: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas6[ans]
                print(respuesta)
            if NumeroPregunta == 7: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas7[ans]
                print(respuesta)
            if NumeroPregunta == 8: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas8[ans]
                print(respuesta)
            if NumeroPregunta == 9: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas9[ans]
                print(respuesta)
            if NumeroPregunta == 10: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas10[ans]
                print(respuesta)
            if NumeroPregunta == 11: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas11[ans]
                print(respuesta)
            if NumeroPregunta == 12: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas12[ans]
                print(respuesta)
            if NumeroPregunta == 13: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas13[ans]
                print(respuesta)
            if NumeroPregunta == 14: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas14[ans]
                print(respuesta)
            if NumeroPregunta ==  15: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas15[ans]
                print(respuesta)
            if NumeroPregunta == 16: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas16[ans]
                print(respuesta)
            if NumeroPregunta == 17: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas17[ans]
                print(respuesta)
            if NumeroPregunta == 18: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas18[ans]
                print(respuesta)
            if NumeroPregunta == 19: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas19[ans]
                print(respuesta)
            if NumeroPregunta == 20: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas20[ans]
                print(respuesta)
            if NumeroPregunta == 21: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas21[ans]
                print(respuesta)
            if NumeroPregunta == 22: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas22[ans]
                print(respuesta)
            if NumeroPregunta == 23: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas23[ans]
                print(respuesta)
            if NumeroPregunta == 24: 
                ans = np.random.randint(1,4)
                print("\n-->")
                respuesta += Respuestas.Respuestas24[ans]
                print(respuesta)               
            if NumeroPregunta == 25:
                print("\n-->")
                respuesta += Respuestas.Respuestas25[1]
                print(respuesta) 
            if NumeroPregunta == 26: 
                print("\n-->")
                respuesta += Respuestas.Respuestas26[1]
                print(respuesta)
            if NumeroPregunta == 27: 
                print("\n-->")
                respuesta += Respuestas.Respuestas27[1]
                print(respuesta)
            if NumeroPregunta == 28: 
                print("\n-->")
                respuesta += Respuestas.Respuestas28[1]
                print(respuesta)
            if NumeroPregunta == 29: 
                print("\n-->")
                respuesta += Respuestas.Respuestas29[1]
                print(respuesta)
            if NumeroPregunta == 30: 
                print("\n-->")
                respuesta += Respuestas.Respuestas30[1]
                print(respuesta)
            if NumeroPregunta == 31: 
                print("\n-->")
                respuesta += Respuestas.Respuestas31[1]
                print(respuesta)
            if NumeroPregunta == None: 
                text = "\nPuedes ser mas especifico con tu pregunta? \n"
                print(text)
            text = "\n--> En que más te puedo ayudar?"
            print(text)
            respuesta += text
            return respuesta
                
    except:
        return "--> Se mas específico en la pregunta o Hay un error en mi sistema, estoy trabajando lo más rapido posible para solucionarlo"