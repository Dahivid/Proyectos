# -*- coding: utf-8 -*-
"""
@author: santi
"""


import re

class KeyWords():
    #Palabras clave pregunta 1
    key1_Q1 = re.compile(r'^(que|qué|cual|cuál)+')
    key2_Q1 = re.compile(r'(estructura)+')
    key3_Q1 = re.compile(r'(datos)+')
    keys1 = [key1_Q1, key2_Q1, key3_Q1]
    #Palabras clave pregunta 2
    key1_Q2 = re.compile(r'^(que|qué|cuales|cuáles)+')
    key2_Q2 = re.compile(r'(tipos|modelos)+')
    key3_Q2 = re.compile(r'(estructura)+')
    keys2 = [key1_Q2, key2_Q2, key3_Q2]
    #Palabras clave pregunta 3
    key1_Q3 = re.compile(r'(origen|procedencia)+')
    key2_Q3 = re.compile(r'(estructura)+')
    keys3 = [key1_Q3, key2_Q3]
    #Palabras clave pregunta 4
    key1_Q4 = re.compile(r'(ejemplo|caso)+')
    key2_Q4 = re.compile(r'(estructura)+')
    key3_Q4 = re.compile(r'(real)+')
    keys4 = [key1_Q4, key2_Q4, key3_Q4]
    #Palabras clave pregunta 5
    key1_Q5 = re.compile(r'(lenguajes)+')
    key2_Q5 = re.compile(r'(implementar|usar|crear)')
    key3_Q5 = re.compile(r'(estructura)+')
    keys5 = [key1_Q5, key2_Q5, key3_Q5]
    #Palabras clave pregunta 6
    key1_Q6 = re.compile(r'(que|qué|definicion|definición)+')
    key2_Q6 = re.compile(r'(arreglos|arreglo|arrays|array)+')
    key3_Q6 = re.compile(r'(programacion|programación)+')
    keys6 = [key1_Q6, key2_Q6, key3_Q6]
    #Palabras clave pregunta 7
    key1_Q7 = re.compile(r'(que|qué|definicion|definición)+')
    key2_Q7 = re.compile(r'(listas|lista|lists|list)+')
    key3_Q7 = re.compile(r'(enlazadas|linked)+')
    keys7 = [key1_Q7, key2_Q7, key3_Q7]
    #Palabras clave pregunta 8
    key1_Q8 = re.compile(r'^(que|qué|cuales)+')
    key2_Q8 = re.compile(r'(pilas|pila|stacks|stack)+')
    keys8 = [key1_Q8, key2_Q8]
    #Palabras clave pregunta 9
    key1_Q9 = re.compile(r'^(que|qué|cuales)+')
    key2_Q9 = re.compile(r'(colas|cola|queue|queues)+')
    keys9 = [key1_Q9, key2_Q9]
    #Palabras clave pregunta 10
    key1_Q10 = re.compile(r'^(que|qué|cuales)+')
    key2_Q10 = re.compile(r'(arboles|árboles|arbol|árbol)+')
    keys10 = [key1_Q10, key2_Q10]
    #Palabras clave pregunta 11
    key1_Q11 = re.compile(r'^(que|qué|cuales)+')
    key2_Q11 = re.compile(r'(grafos|grafo)+')
    keys11 = [key1_Q11, key2_Q11]
    #Palabras clave pregunta 12
    key1_Q12 = re.compile(r'^(que|qué|cuales)+')
    key2_Q12 = re.compile(r'(tablas|tabla|tables|table)+')
    key3_Q12 = re.compile(r'(hash|hash)+')
    keys12 = [key1_Q12, key2_Q12, key3_Q12]
    #Palabras clave pregunta 13
    key1_Q13 = re.compile(r'(que|qué|cual|cuál|cuales)+')
    key2_Q13 = re.compile(r'(diferencia|distinguen|difieren|distingue)+')
    key3_Q13 = re.compile(r'(arreglos|arreglo|arrays|array)+')
    key4_Q13 = re.compile(r'(listas|lista|lists|list)+')
    keys13 = [key1_Q13, key2_Q13, key3_Q13, key4_Q13]
    #Palabras clave pregunta 14
    key1_Q14 = re.compile(r'^(que|qué|cuales)+')
    key2_Q14 = re.compile(r'(estructura)+')
    key3_Q14 = re.compile(r'(dinámica|dinamica)+')
    keys14 = [key1_Q14, key2_Q14, key3_Q14]
    #Palabras clave pregunta 15
    key1_Q15 = re.compile(r'(diferencias|diferencia|distintas|distinguen|distingue)+')
    key2_Q15 = re.compile(r'(pila|pilas|stacks|stack)+')
    key3_Q15 = re.compile(r'(colas|cola|queue|queues)+')
    keys15 = [key1_Q15, key2_Q15, key3_Q15]
    #Palabras clave pregunta 16
    key1_Q16 = re.compile(r'(que|qué)+')
    key2_Q16 = re.compile(r'(arbol|árbol)+')
    key3_Q16 = re.compile(r'(avl)+')
    keys16 = [key1_Q16, key2_Q16, key3_Q16]
    #Palabras clave pregunta 17
    key1_Q17 = re.compile(r'(distinto|diferencias)+')
    key2_Q17 = re.compile(r'(arbol|árbol)+')
    key3_Q17 = re.compile(r'(binario)+')
    keys17 = [key1_Q17, key2_Q17, key3_Q17]
    #Palabras clave pregunta 18
    key1_Q18 = re.compile(r'(listas|lista|list|lists)+')
    key2_Q18 = re.compile(r'(tiempo|cronologia|cronología)+')
    key3_Q18 = re.compile(r'(constante|continuo)+')
    keys18 = [key1_Q18, key2_Q18, key3_Q18]
    #Palabras clave pregunta 19
    key1_Q19 = re.compile(r'(arbol|árbol)+')
    key2_Q19 = re.compile(r'(genealogico|genealógico|familiar)+')
    keys19 = [key1_Q19, key2_Q19]
    #Palabras clave pregunta 20
    key1_Q20 = re.compile(r'(complejidad|dificultad)+')
    key2_Q20 = re.compile(r'(arbol|árbol)+')
    keys20 = [key1_Q20, key2_Q20]
    #Palabras clave pregunta 21
    key1_Q21 = re.compile(r'(complejidad|dificultad)+')
    key2_Q21 = re.compile(r'(push|insertar)+')
    key3_Q21 = re.compile(r'(pop|eliminar)+')
    key4_Q21 = re.compile(r'(pila|pilas|stacks|stack)+')
    keys21 = [key1_Q21, key2_Q21, key3_Q21, key4_Q21]
    #Palabras clave pregunta 22
    key1_Q22 = re.compile(r'(complejidad|dificultad)+')
    key2_Q22 = re.compile(r'(insercion|inserción)+')
    key3_Q22 = re.compile(r'(eliminación|eliminacion)+')
    keys22 = [key1_Q22, key2_Q22, key3_Q22]
    #Palabras clave pregunta 23
    key1_Q23 = re.compile(r'(recursivas|recursividad)+')
    keys23 = [key1_Q23]
    #Palabras clave pregunta 24
    key1_Q24 = re.compile(r'(hash)+')
    key2_Q24 = re.compile(r'(lista|listas|list|lists)+')
    key3_Q24 = re.compile(r'(busqueda|búsqueda)+')
    keys24 = [key1_Q24, key2_Q24, key3_Q24]
    #Palabras clave pregunta 25
    key1_Q25 = re.compile(r'(hacer|crear|diseñar|programar)+')
    key2_Q25 = re.compile(r'(arreglo|arreglo|array|arrays)+')
    keys25 = [key1_Q25, key2_Q25]
    #Palabras clave pregunta 26
    key1_Q26 = re.compile(r'(hacer|crear|diseñar|programar)+')
    key2_Q26 = re.compile(r'(lista|listas|list|lists)+')
    keys26 = [key1_Q26, key2_Q26]
    #Palabras clave pregunta 27
    key1_Q27 = re.compile(r'(hacer|crear|diseñar|programar)+')
    key2_Q27 = re.compile(r'(pila|pilas|stack|stacks)+')
    keys27 = [key1_Q27, key2_Q27]
    #Palabras clave pregunta 28
    key1_Q28 = re.compile(r'(hacer|crear|diseñar|programar)+')
    key2_Q28 = re.compile(r'(cola|colas|queue|queues)+')
    keys28 = [key1_Q28, key2_Q28]
    #Palabras clave pregunta 29
    key1_Q29 = re.compile(r'(hacer|crear|diseñar|programar)+')
    key2_Q29 = re.compile(r'(arbol|árbol|arboles|árboles)+')
    keys29 = [key1_Q29, key2_Q29]
    #Palabras clave pregunta 30
    key1_Q30 = re.compile(r'(hacer|crear|diseñar|programar)+')
    key2_Q30 = re.compile(r'(grafo|grafos)+')
    keys30 = [key1_Q30, key2_Q30]
    #Palabras clave pregunta 31
    key1_Q31 = re.compile(r'(hacer|crear|diseñar|programar)+')
    key2_Q31 = re.compile(r'(hash)+')
    keys31 = [key1_Q31, key2_Q31]
    
    def __init__(self):
        """constructor"""
    
    def __del__(self):
        """Destructor"""
        print("Destruyendo palabras clave")
        
    def __str__(self):
        """Devuelve descripcion de clase"""
        cad = "Palabras clave de 31 preguntas sobre estructuras de datos"
        return cad

