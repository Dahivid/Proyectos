from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from myprojec import main
@csrf_exempt
def enviar_mensaje(request):
    if request.method == 'POST':
        message = request.POST.get('message')
        ans=main.main(message)
        # Realizar alg�n procesamiento o l�gica con el mensaje aqu�
        # ...
        
        if message == 'hola':
            response = {
                'message': 'Soy tu asistente de estructuras de datos, que deseas saber?',
            }
        else:
            response = {
                'message': ans,
            }

        return JsonResponse(response)