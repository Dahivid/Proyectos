# -*- coding: utf-8 -*-
"""
@author: santi
"""
import re

def ListaCoincidencias(keys, question):
    coincidencias = []
    for i in keys:
        coincidencias += re.findall(i, question.lower())
    return coincidencias