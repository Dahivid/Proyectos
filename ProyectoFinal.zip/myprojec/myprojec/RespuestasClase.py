# -*- coding: utf-8 -*-
"""
@author: santi
"""
class Respuestas():
    Respuestas1 = {1: "En programación, una estructura de datos se refiere a una forma de organizar" +
             "y almacenar datos en una computadora de manera eficiente para que puedan ser procesados"+
             " y utilizados de manera efectiva por un programa.",
             2: "Las estructuras de datos son formas de organizar y almacenar datos en la memoria"+
             " de un programa de computadora. En programación, se utilizan para representar y"+
             " manipular datos de manera eficiente y efectiva.",
             3: "Las estructuras de datos son formas de organizar y almacenar datos en un programa"+
             " de computadora. Estas estructuras pueden incluir arreglos (arrays),"+
             " listas enlazadas (linked lists), pilas (stacks), colas (queues), "+
             "árboles (trees), grafos (graphs), entre otros."}
    
    Respuestas2 = {1: "Hay muchos tipos de estructuras de datos, pero aquí se presentan algunos de los más comunes: \n"+
                  "-> Arreglos (Arrays): estructura de datos que almacena un conjunto de elementos del mismo tipo en una secuencia contigua de memoria.\n"+
                  "-> Listas Enlazadas (Linked Lists): estructura de datos en la que cada elemento, llamado nodo, contiene un valor y una referencia al siguiente nodo.\n"+
                  "-> Pilas (Stacks): estructura de datos en la que los elementos se insertan y eliminan según el principio de LIFO (Last In, First Out).\n"+
                  "-> Colas (Queues): estructura de datos en la que los elementos se insertan al final y se eliminan del principio según el principio de FIFO (First In, First Out).\n"+
                  "-> Árboles (Trees): estructura de datos jerárquica que consiste en nodos conectados por ramas, donde cada nodo tiene cero o más nodos hijos.\n"+
                  "-> Grafos (Graphs): estructura de datos no lineal que consiste en nodos conectados por aristas, donde cada nodo puede tener cero o más aristas.\n"+
                  "-> Tablas de Hash (Hash Tables): estructura de datos que utiliza una función hash para mapear claves a valores, permitiendo una búsqueda eficiente de los valores asociados a una clave.",
                  2: "Existen numerosos tipos de estructuras de datos utilizadas en programación, algunas de las cuales son: \n"+
                  "-> Arreglos (Arrays): son estructuras de datos lineales que permiten almacenar un conjunto de elementos del mismo tipo. Los elementos se almacenan de manera contigua en la memoria y se acceden mediante un índice.\n"+
                  "-> Listas Enlazadas (Linked Lists): son estructuras de datos lineales que consisten en una serie de nodos enlazados entre sí, donde cada nodo contiene un valor y una referencia al siguiente nodo.\n"+
                  "-> Pilas (Stacks): son estructuras de datos lineales que siguen el principio LIFO (Last In First Out), lo que significa que el último elemento agregado es el primero en ser eliminado.\n"+
                  "-> Colas (Queues): son estructuras de datos lineales que siguen el principio FIFO (First In First Out), lo que significa que el primer elemento agregado es el primero en ser eliminado.\n"+
                  "-> Árboles (Trees): son estructuras de datos no lineales que consisten en un conjunto de nodos interconectados. Cada nodo tiene un valor y uno o más nodos hijos.\n"+
                  "-> Grafos (Graphs): son estructuras de datos no lineales que consisten en un conjunto de nodos (vértices) interconectados por aristas.\n"+
                  "-> Hash Tables: son estructuras de datos que utilizan una función hash para asignar una clave a un valor, lo que permite una búsqueda rápida y eficiente de los datos.",
                  3: "Hay muchos tipos de estructuras de datos en programación, aquí te presento algunos de los más comunes: \n"+
                  "-> Arreglos (Arrays): son estructuras de datos que almacenan un conjunto de elementos del mismo tipo en una posición continua de memoria.\n"+
                  "-> Listas enlazadas (Linked Lists): son estructuras de datos que almacenan un conjunto de elementos del mismo tipo de forma no contigua, donde cada elemento se conecta con el siguiente mediante un puntero.\n"+
                  "-> Pilas (Stacks): son estructuras de datos que siguen el principio LIFO (Last-In, First-Out), es decir, el último elemento que se ingresa es el primero en ser retirado.\n"+
                  "-> Colas (Queues): son estructuras de datos que siguen el principio FIFO (First-In, First-Out), es decir, el primer elemento que se ingresa es el primero en ser retirado.\n"+
                  "-> Árboles (Trees): son estructuras de datos jerárquicas que consisten en un conjunto de nodos conectados por enlaces.\n"+
                  "-> Grafos (Graphs): son estructuras de datos que representan una colección de vértices (nodos) conectados por aristas (enlaces).\n"+
                  "-> Tablas Hash (Hash Tables): son estructuras de datos que almacenan pares clave-valor, y utilizan una función hash para calcular la ubicación de almacenamiento de los datos."}
    
    Respuestas3 = {1: "El concepto de estructuras de datos en programación se originó en la "+
                   "década de 1950, cuando los programadores comenzaron a trabajar en la"+
                   " construcción de programas complejos que requerían una gestión eficiente"+
                   " de grandes cantidades de datos.\n" + 
                   "Uno de los primeros pioneros en la teoría de estructuras de datos fue el"+
                   " matemático y científico de la computación norteamericano John von Neumann,"+
                   " quien en la década de 1940 desarrolló el concepto de la arquitectura de Von"+
                   " Neumann, que proporcionó la base para la creación de las primeras computadoras modernas.\n"+
                   "Uno de los primeros lenguajes de programación que incluyó estructuras de "+
                   "datos como parte integral de su diseño fue Algol 68, que se desarrolló a "+
                   "finales de la década de 1960. A partir de entonces, los conceptos de "+
                   "estructuras de datos han sido una parte fundamental del diseño de lenguajes"+
                   " de programación y la programación en general.",
                   2: "Las estructuras de datos han sido una parte integral de la informática"+
                   " desde sus primeros días. El concepto de estructuras de datos surgió a "+
                   "principios del siglo XX, cuando los matemáticos comenzaron a estudiar la "+
                   "teoría de conjuntos y la lógica simbólica. Sin embargo, su aplicación en la"+
                   " informática se remonta a la década de 1950, cuando se desarrollaron los "+
                   "primeros lenguajes de programación de alto nivel.\n"
                   "En la década de 1960, el campo de las estructuras de datos comenzó a tomar "+
                   "forma como una disciplina independiente, y se desarrollaron varias "+
                   "estructuras de datos importantes, como las listas enlazadas, las pilas y "+
                   "las colas. Desde entonces, se han desarrollado muchas otras estructuras de "+
                   "datos y se han mejorado las existentes.",
                   3: "El origen de las estructuras de datos se remonta a la década de 1950,"+
                   " cuando los primeros lenguajes de programación comenzaron a aparecer."+
                   " En esa época, los programadores se dieron cuenta de que necesitaban formas"+
                   " más sofisticadas de manejar los datos que simplemente almacenarlos en "+
                   "variables individuales.\n"+
                   "Uno de los primeros enfoques para manejar datos complejos fue el uso de "+
                   "arreglos, que permitían a los programadores almacenar conjuntos de datos "+
                   "del mismo tipo de manera eficiente. Sin embargo, los arreglos tenían "+
                   "limitaciones en términos de flexibilidad, lo que llevó al desarrollo de "+
                   "otras estructuras de datos, como las listas enlazadas, pilas y colas.\n"+
                   "A medida que la programación evolucionó y las aplicaciones se volvieron "+
                   "más complejas, se desarrollaron otras estructuras de datos más avanzadas,"+
                   " como árboles y grafos. Estas estructuras de datos se volvieron cada vez más"+
                   " importantes a medida que las aplicaciones comenzaron a manejar grandes "+
                   "cantidades de datos y requerían operaciones de búsqueda y recuperación más sofisticadas.\n"}
    
    Respuestas4 = {1: "Las estructuras de datos son utilizadas no solo en la programación, sino también en muchos ámbitos de la vida real, como por ejemplo:\n"+
                  "-> Listas de compras: al hacer una lista de compras, se puede utilizar una estructura de datos simple como una lista para mantener un registro de los elementos que se deben comprar y tacharlos cuando se adquieren.\n"+
                  "-> Agenda telefónica: una agenda telefónica es una estructura de datos que se utiliza para almacenar información de contacto como nombres, números de teléfono y correos electrónicos.\n"+
                  "-> Mapas: los mapas son estructuras de datos utilizadas para representar la geografía, la topografía y las relaciones entre objetos y lugares.\n"+
                  "-> Sistemas de gestión de bases de datos: los sistemas de gestión de bases de datos (DBMS, por sus siglas en inglés) utilizan estructuras de datos complejas para almacenar y organizar grandes cantidades de datos.\n"+
                  "-> Redes sociales: los sitios web y aplicaciones de redes sociales utilizan estructuras de datos para almacenar y organizar información de usuario, publicaciones y relaciones sociales.\n"+
                  "-> Sistemas de transporte público: los sistemas de transporte público utilizan estructuras de datos para planificar rutas, horarios y asignaciones de vehículos.\n"+
                  "-> Bibliotecas: las bibliotecas utilizan estructuras de datos para organizar y mantener registros de libros, autores, préstamos y devoluciones.\n"+
                  "Estos son solo algunos ejemplos de cómo las estructuras de datos se utilizan en la vida real. En general, cualquier situación en la que se necesite almacenar, organizar o acceder a información de manera eficiente puede beneficiarse del uso de estructuras de datos.",
                  2: "Las estructuras de datos se utilizan en muchos aspectos de la vida real, desde la organización de la información en una base de datos hasta la estructuración de la información en una página web. A continuación, algunos ejemplos de estructuras de datos en la vida real:\n"+
                  "-> Listas de contactos en el teléfono móvil: Los contactos de un teléfono móvil pueden organizarse en una lista enlazada, donde cada elemento contiene información como el nombre, número de teléfono y dirección de correo electrónico de una persona.\n"+
                  "-> Sistemas de gestión de inventario: Las empresas pueden utilizar estructuras de datos como los árboles o los gráficos para organizar y realizar un seguimiento de su inventario. Por ejemplo, un árbol podría utilizarse para representar las categorías de productos y sus subcategorías.\n"+
                  "-> Redes sociales: Las redes sociales utilizan estructuras de datos como grafos para representar las relaciones entre usuarios y para recomendaciones de amigos basados en conexiones existentes.\n"+
                  "-> Sistemas de navegación GPS: Los sistemas de navegación GPS utilizan estructuras de datos como los árboles para representar las calles y las rutas posibles en una ciudad.\n"+
                  "-> Bases de datos: Las bases de datos utilizan diferentes tipos de estructuras de datos para organizar y almacenar la información. Por ejemplo, una tabla en una base de datos relacional utiliza una estructura de datos de matriz para organizar los datos en filas y columnas.\n"+
                  "Estos son solo algunos ejemplos de cómo se utilizan las estructuras de datos en la vida real. En general, las estructuras de datos son una herramienta fundamental en la informática y se utilizan en una amplia variedad de aplicaciones.",
                  3: "Las estructuras de datos se utilizan en muchas aplicaciones de la vida real, a continuación te daré algunos ejemplos:\n"+
                  "-> Agenda telefónica: una agenda telefónica es una estructura de datos que almacena información de contacto, como nombres, direcciones y números de teléfono, en una lista o tabla para facilitar su acceso y búsqueda.\n"+
                  "-> Base de datos de una empresa: una base de datos de una empresa es una estructura de datos que almacena información de clientes, productos y ventas para que la empresa pueda administrar sus operaciones y tomar decisiones informadas.\n"+
                  "-> Red social: una red social como Facebook o Twitter es una estructura de datos que almacena información de perfil, publicaciones, comentarios y conexiones de amistad entre usuarios para que los usuarios puedan interactuar entre sí.\n"+
                  "-> Archivos de sistema operativo: los sistemas operativos utilizan estructuras de datos como archivos y directorios para organizar y almacenar datos y programas en la computadora.\n"+
                  "-> Sistemas de navegación GPS: los sistemas de navegación GPS utilizan estructuras de datos como mapas, rutas y ubicaciones para proporcionar indicaciones precisas de navegación.\n"+
                  "-> Sistemas de gestión de inventarios: los sistemas de gestión de inventarios utilizan estructuras de datos como listas y tablas para rastrear el inventario de productos y gestionar el abastecimiento.\n"+
                  "-> Sistemas de reserva en línea: los sistemas de reserva en línea utilizan estructuras de datos como calendarios, listas y tablas para rastrear y administrar reservas de hoteles, vuelos, eventos y otros servicios.\n"+
                  "Estos son solo algunos ejemplos de cómo las estructuras de datos se utilizan en la vida real. En general, cualquier situación en la que se necesite almacenar, organizar o acceder a información de manera eficiente puede beneficiarse del uso de estructuras de datos."}
    
    Respuestas5 = {1: "Las estructuras de datos se pueden implementar en la mayoría de los lenguajes de programación. De hecho, la capacidad de trabajar con estructuras de datos es esencial en la mayoría de los programas.\n"+
                   "A continuación, te menciono algunos ejemplos de lenguajes de programación populares que admiten estructuras de datos:\n"+
                   "-> C: es un lenguaje de programación de bajo nivel que proporciona estructuras de datos integradas, como matrices, punteros y estructuras, para trabajar con datos complejos.\n"+
                   "-> C++: es un lenguaje de programación orientado a objetos que proporciona una amplia variedad de estructuras de datos integradas, como vectores, listas, pilas, colas y árboles.\n"+
                   "-> Java: es un lenguaje de programación orientado a objetos que proporciona una amplia variedad de estructuras de datos integradas, como listas, pilas, colas, árboles y mapas.\n"+
                   "-> Python: es un lenguaje de programación interpretado que admite una amplia variedad de estructuras de datos integradas, como listas, diccionarios, conjuntos y tuplas.\n"+
                   "-> JavaScript: es un lenguaje de programación interpretado que proporciona estructuras de datos integradas, como matrices y objetos, y admite bibliotecas de estructuras de datos más complejas.\n"+
                   "-> PHP: es un lenguaje de programación de código abierto que admite una amplia variedad de estructuras de datos integradas, como matrices, objetos y listas enlazadas.\n"+
                   "En general, la mayoría de los lenguajes de programación modernos proporcionan estructuras de datos integradas o permiten el uso de bibliotecas para trabajar con estructuras de datos complejas.",
                   2: "Las estructuras de datos se pueden implementar en muchos lenguajes de programación diferentes. Aquí te menciono algunos ejemplos de lenguajes de programación que soportan estructuras de datos:\n"+
                   "-> C/C++: C y C++ son lenguajes de programación muy populares para trabajar con estructuras de datos, ya que proporcionan acceso directo a la memoria y permiten la manipulación de datos de manera eficiente.\n"+
                   "-> Java: Java es un lenguaje de programación orientado a objetos que tiene una amplia gama de estructuras de datos disponibles en su biblioteca estándar, como listas, conjuntos, mapas, árboles, colas y pilas.\n"+
                   "-> Python: Python es un lenguaje de programación interpretado que también proporciona muchas estructuras de datos integradas, como listas, tuplas, diccionarios, conjuntos, árboles y colas.\n"+
                   "-> Ruby: Ruby es un lenguaje de programación interpretado que proporciona una amplia gama de estructuras de datos integradas, como listas, matrices, hashes, conjuntos, árboles y colas.\n"+
                   "-> JavaScript: JavaScript es un lenguaje de programación de scripting que se utiliza comúnmente en aplicaciones web y proporciona estructuras de datos como matrices, objetos y mapas.\n"+
                   "Hay muchos otros lenguajes de programación que admiten estructuras de datos, pero estos son solo algunos ejemplos comunes. La elección del lenguaje de programación dependerá del problema que se esté intentando resolver y las necesidades del programa.",
                   3: "Las estructuras de datos se pueden implementar en muchos lenguajes de programación diferentes. Algunos de los lenguajes de programación más comunes para la implementación de estructuras de datos incluyen:\n"+
                   "-> C: es un lenguaje de programación popular para la implementación de estructuras de datos debido a su capacidad para trabajar con punteros y su eficiencia en términos de memoria.\n"+
                   "-> Java: es otro lenguaje de programación comúnmente utilizado para la implementación de estructuras de datos. Java proporciona una amplia biblioteca de estructuras de datos integradas, como listas, colas, pilas y árboles.\n"+
                   "-> Python: es un lenguaje de programación popular que incluye una amplia biblioteca de estructuras de datos incorporadas, como listas, tuplas, diccionarios y conjuntos.\n"+
                   "-> C++: es un lenguaje de programación orientado a objetos que proporciona una amplia biblioteca de estructuras de datos integradas, como vectores, listas, colas y pilas.\n"+
                   "-> JavaScript: es un lenguaje de programación comúnmente utilizado para la implementación de estructuras de datos en aplicaciones web y móviles, ya que es compatible con la manipulación de DOM y proporciona objetos integrados como arrays y objetos.\n"+
                   "Estos son solo algunos ejemplos de lenguajes de programación que se pueden utilizar para implementar estructuras de datos. En general, cualquier lenguaje de programación que permita la manipulación de datos y la gestión de la memoria se puede utilizar para implementar estructuras de datos."}
    
    Respuestas6 = {1: "En programación, un arreglo (también conocido como array) es una"+
                   " estructura de datos que se utiliza para almacenar una colección de"+
                   " elementos del mismo tipo en una ubicación contigua de la memoria de "+
                   "una computadora. Cada elemento del arreglo se identifica por un índice"+
                   " numérico, que indica su posición en el arreglo, y es útil para trabajar"+
                   " con grandes conjuntos de datos y realizar operaciones de procesamiento de datos.",
                   2: " Los arreglos son una herramienta poderosa en la programación porque"+
                   " permiten la manipulación eficiente de grandes cantidades de datos en"+
                   " memoria. Además, los índices en los arreglos permiten un acceso rápido "+
                   "y directo a los elementos individuales del arreglo. Los arreglos se utilizan"+
                   " en una amplia variedad de aplicaciones de programación, desde la"+
                   " representación de datos en estructuras de datos más complejas"+
                   " hasta el procesamiento de datos en algoritmos de ordenamiento y búsqueda.",
                   3: "En esencia, un arreglo es una colección ordenada de elementos,"+
                   " cada uno de los cuales se identifica mediante un índice o posición. "+
                   "El primer elemento de un arreglo tiene un índice de 0, el segundo "+
                   "elemento tiene un índice de 1, y así sucesivamente. El tamaño de un"+
                   " arreglo se define al momento de su creación y no puede ser cambiado durante la ejecución del programa."+
                   "Los arreglos pueden ser unidimensionales, que es la forma más común, "+
                   "o multidimensionales (también conocidos como matrices). En un arreglo "+
                   "multidimensional, los elementos se organizan en filas y columnas, y "+
                   "se pueden acceder mediante un par de índices."}
    
    Respuestas7 = {1: "En programación, una lista enlazada (también conocida como linked list)"+
                   " es una estructura de datos dinámica que consta de nodos enlazados entre"+
                   " sí. Cada nodo contiene un valor y un puntero (o referencia) que apunta"+
                   " al siguiente nodo en la lista. El primer nodo se conoce como la cabeza"+
                   " (o inicio) de la lista, mientras que el último nodo apunta a null, lo"+
                   " que indica el final de la lista."+
                   "A diferencia de los arreglos, las listas enlazadas no tienen un tamaño"+
                   " fijo y pueden crecer o disminuir dinámicamente durante la ejecución "+
                   "del programa. Además, los elementos de una lista enlazada no necesitan"+
                   " estar almacenados de manera contigua en memoria, lo que permite una mayor"+
                   " flexibilidad y eficiencia en términos de espacio."+
                   "Las listas enlazadas se utilizan para implementar estructuras de datos"+
                   " como pilas, colas y árboles, así como para resolver problemas de "+
                   "manipulación de datos en general. Algunas de las operaciones comunes"+
                   " que se pueden realizar en una lista enlazada incluyen la inserción y"+
                   " eliminación de elementos, la búsqueda de elementos y la reversión de la lista.",
                   2: "En programación, una lista enlazada es una estructura de datos "+
                   "lineal en la que los elementos se almacenan en nodos. Cada nodo contiene"+
                   " dos campos: uno para almacenar el elemento y otro para apuntar al "+
                   "siguiente nodo en la lista.\n"+
                   "A diferencia de los arreglos, en los que los elementos se almacenan "+
                   "de forma contigua en la memoria, los nodos de una lista enlazada pueden"+
                   " estar dispersos en la memoria. Cada nodo solo conoce la ubicación del"+
                   " siguiente nodo en la lista, lo que permite que los nodos se puedan"+
                   " insertar o eliminar de la lista de manera eficiente.\n"+
                   "Hay diferentes tipos de listas enlazadas, incluyendo:\n"+
                   "-> Lista enlazada simple: cada nodo apunta solo al siguiente nodo en la lista.\n"+
                   "-> Lista enlazada doble: cada nodo tiene dos punteros, uno para el nodo anterior y otro para el siguiente nodo en la lista.\n"+
                   "-> Lista enlazada circular: la lista comienza y termina en el mismo nodo, formando un bucle.\n",
                   3: "En programación, una lista enlazada (también conocida como lista ligada"+
                   " o simplemente lista) es una estructura de datos dinámica que consta de un "+
                   "conjunto de nodos, cada uno de los cuales contiene un valor y un puntero"+
                   " que apunta al siguiente nodo en la lista.\n"+
                   "A diferencia de los arreglos, las listas enlazadas no se almacenan en"+
                   " una ubicación de memoria contigua. En cambio, cada nodo en la lista"+
                   " enlazada se almacena en una ubicación de memoria separada y se enlaza "+
                   "al siguiente nodo mediante un puntero.\n"+
                   "Las listas enlazadas se pueden implementar en diferentes lenguajes de "+
                   "programación como C, C++, Java, Python, entre otros. Al trabajar con"+
                   " listas enlazadas, se debe tener cuidado de evitar los errores de puntero"+
                   " nulo, como intentar acceder a un puntero que no está apuntando a ningún nodo.\n"}
    
    Respuestas8 = {1: "En programación, una pila (también conocida como stack) es una estructura de datos que sigue el principio de LIFO (Last In, First Out), lo que significa que el último elemento que se inserta en la pila es el primero en ser eliminado. La pila se puede visualizar como una pila de platos, en la que el último plato que se coloca en la pila es el primero en ser retirado.\n"+
                   "La pila tiene dos operaciones principales: push (insertar un elemento en la pila) y pop (eliminar el elemento más reciente de la pila). También se puede implementar la operación peek, que devuelve el elemento superior de la pila sin eliminarlo.\n"+
                   "La pila se puede implementar utilizando un arreglo o una lista enlazada. Cuando se implementa utilizando un arreglo, se puede usar un puntero para realizar un seguimiento de la cima de la pila. Cuando se implementa utilizando una lista enlazada, se utiliza el primer nodo como la cima de la pila.\n"+
                   "Las pilas se utilizan en muchos algoritmos y estructuras de datos, como la evaluación de expresiones matemáticas, la reversión de una cadena, la gestión de llamadas de funciones en un programa y la resolución de problemas de recursividad.",
                   2: "En programación, una pila (también conocida como stack) es una estructura de datos lineal que permite el acceso a elementos solo en un extremo de la estructura, llamado la cima (top en inglés). Los elementos en una pila se organizan según el principio \"último en entrar, primero en salir\" (LIFO por sus siglas en inglés, Last-In-First-Out).\n"+
                   "Las pilas se pueden implementar como una lista enlazada o un arreglo, pero en cualquier caso, las operaciones principales que se pueden realizar en una pila son:\n"+
                   "-> Push: Agregar un elemento a la cima de la pila\n"+
                   "-> Pop: Remover el elemento en la cima de la pila\n"+
                   "-> Peek: Obtener el valor del elemento en la cima de la pila sin removerlo\n"+
                   "-> isEmpty: Verificar si la pila está vacía\n"+
                   "Es importante tener en cuenta que las pilas tienen una capacidad limitada, lo que significa que una pila llena no puede aceptar más elementos, lo que puede dar lugar a errores de desbordamiento de pila (stack overflow) si se intenta agregar más elementos.",
                   3: "En programación, una pila (también conocida como stack) es una estructura de datos lineal que sigue el principio de LIFO (Last-In, First-Out), lo que significa que el último elemento en ser agregado a la pila es el primero en ser eliminado.\n"+
                   "La pila es como una lista en la que los elementos se agregan y eliminan solo desde un extremo, denominado \"cima\" o \"tope\" de la pila. Los elementos agregados más recientemente se ubican en la cima de la pila, mientras que los elementos más antiguos se ubican en la parte inferior.\n"+
                   "La pila proporciona dos operaciones principales: push (agregar un elemento a la cima de la pila) y pop (eliminar un elemento de la cima de la pila). También se puede implementar la operación peek (observar el elemento en la cima de la pila sin eliminarlo).\n"+
                   "Las pilas se utilizan en una amplia variedad de aplicaciones en programación, como la reversión de cadenas, la validación de sintaxis en compiladores, la navegación en un árbol binario y la implementación de algoritmos de búsqueda en profundidad en grafos.\n"+
                   "Las pilas se pueden implementar en diferentes lenguajes de programación utilizando arreglos o listas enlazadas. La implementación de una pila también se puede realizar mediante el uso de las pilas integradas en la biblioteca estándar de un lenguaje de programación."}
    
    Respuestas9 = {1: "En programación, una cola (también conocida como queue) es una estructura de datos lineal que sigue el principio de FIFO (First-In, First-Out), lo que significa que el primer elemento en ser agregado a la cola es el primero en ser eliminado.\n"+
                   "La cola se asemeja a una fila en la que los elementos se agregan al final de la cola y se eliminan del frente de la cola. El elemento agregado primero se encuentra en el frente de la cola, mientras que el último elemento se encuentra en la parte posterior.\n"+
                   "La cola proporciona dos operaciones principales: enqueue (agregar un elemento al final de la cola) y dequeue (eliminar un elemento del frente de la cola). También se puede implementar la operación peek (observar el elemento en el frente de la cola sin eliminarlo).\n"+
                   "Las colas se utilizan en una amplia variedad de aplicaciones en programación, como la planificación de procesos, el manejo de solicitudes de red, la impresión de trabajos y la implementación de algoritmos de búsqueda en anchura en grafos.\n"+
                   "Las colas se pueden implementar en diferentes lenguajes de programación utilizando arreglos o listas enlazadas. También se pueden implementar mediante el uso de colas integradas en la biblioteca estándar de un lenguaje de programación.",
                   2: "En programación, una cola (también conocida como queue) es una estructura de datos lineal que sigue el principio de FIFO (First-In, First-Out), lo que significa que el primer elemento en ser agregado a la cola es el primer elemento en ser eliminado.\n"+
                   "La cola es similar a una pila, con la diferencia de que los elementos se eliminan del otro extremo de la estructura, denominado \"frente\" o \"head\" de la cola, mientras que los elementos se agregan al final de la cola, denominado \"final\" o \"tail\".\n"+
                   "Las colas también proporcionan dos operaciones principales: enqueue (agregar un elemento al final de la cola) y dequeue (eliminar un elemento del frente de la cola). También se puede implementar la operación peek (observar el elemento en el frente de la cola sin eliminarlo).\n"+
                   "Las colas se utilizan en una variedad de aplicaciones en programación, como la gestión de procesos en sistemas operativos, la planificación de recursos en redes, la impresión en cola y la simulación de eventos discretos",
                   3: "En programación, una cola (también conocida como queue) es una estructura de datos lineal que sigue el principio de FIFO (First-In, First-Out), lo que significa que el primer elemento en ser agregado a la cola es el primero en ser eliminado.\n"
                   "Las colas se pueden imaginar como una fila de personas que espera para entrar en algún lugar, donde la primera persona que llega es la primera en entrar. De manera similar, en una cola de programación, el primer elemento que se agrega es el primer elemento en ser eliminado.\n"+
                   "Las colas tienen dos operaciones principales: enqueue (agregar un elemento al final de la cola) y dequeue (eliminar el primer elemento de la cola). También se puede implementar la operación peek (observar el primer elemento en la cola sin eliminarlo).\n"+
                   "Las colas se utilizan en una amplia variedad de aplicaciones en programación, como el procesamiento de tareas en un servidor de aplicaciones, la administración de trabajos en un sistema operativo, la gestión de paquetes de red en aplicaciones de red y la simulación de sistemas de espera."}
    
    Respuestas10 = {1: "En programación, un árbol es una estructura de datos no lineal que se compone de nodos conectados por enlaces llamados bordes o ramas. Cada nodo en un árbol tiene un padre (excepto el nodo raíz) y puede tener uno o más hijos.\n"+
                    "La parte superior del árbol se llama nodo raíz, y los nodos que no tienen hijos se llaman nodos hoja. Los nodos que comparten el mismo padre se llaman hermanos. La profundidad de un nodo se refiere a la longitud del camino desde el nodo raíz hasta el nodo, y la altura de un árbol se refiere a la profundidad máxima de cualquier nodo en el árbol.\n"+
                    "Los árboles se utilizan en una amplia variedad de aplicaciones en programación, como en la representación de estructuras de datos complejas, la búsqueda de información, la organización de datos jerárquicos y la optimización de algoritmos.\n"+
                    "Algunos tipos comunes de árboles incluyen árboles binarios, árboles de búsqueda binaria, árboles AVL, árboles B y árboles de decisión.\n"+
                    "Los árboles se pueden implementar en diferentes lenguajes de programación utilizando estructuras de datos como punteros o referencias. La implementación de un árbol también se puede realizar mediante el uso de las bibliotecas de árboles integradas en la biblioteca estándar de un lenguaje de programación.",
                    2: "En programación, un árbol es una estructura de datos no lineal que consta de nodos conectados por aristas o enlaces, que se utiliza para representar una jerarquía o relación entre elementos. Cada nodo del árbol puede tener un número variable de hijos o subárboles.\n"+
                    "El nodo superior del árbol se llama raíz y los nodos sin hijos se llaman hojas. Los nodos intermedios se llaman nodos internos y tienen al menos un hijo.\n"+
                    "Los árboles se utilizan en una amplia variedad de aplicaciones en programación, como la representación de estructuras de datos jerárquicas como el sistema de archivos de un sistema operativo, la representación de la estructura sintáctica de un lenguaje de programación, la representación de relaciones de genealogía en bases de datos, y la representación de relaciones de dependencia en algoritmos de planificación y optimización.\n"+
                    "Existen varios tipos de árboles en programación, como el árbol binario, el árbol de búsqueda binaria, el árbol AVL, el árbol rojo-negro, el árbol B, el árbol B+ y el árbol Trie. Cada tipo de árbol tiene características y aplicaciones específicas.\n"+
                    "Los árboles se pueden implementar en diferentes lenguajes de programación utilizando estructuras de datos como punteros, arreglos y listas enlazadas. También hay bibliotecas y marcos disponibles en muchos lenguajes de programación para facilitar la creación y manipulación de árboles.",
                    3: "En programación, un árbol es una estructura de datos no lineal que consta de un conjunto de nodos conectados por enlaces llamados ramas o bordes. La estructura del árbol se parece a la estructura de un árbol en la naturaleza, donde cada nodo se conecta a otros nodos de manera jerárquica y ramificada.\n"+
                    "Un árbol consta de un nodo raíz que es el nodo superior del árbol y cero o más nodos secundarios. Cada nodo secundario se puede conectar a otros nodos secundarios y así sucesivamente, creando una jerarquía en el árbol. Los nodos que no tienen ningún nodo secundario se llaman hojas.\n"+
                    "Cada nodo en el árbol puede tener cero o más nodos secundarios, y cada nodo secundario solo puede tener un nodo padre. La relación entre los nodos se llama relación padre-hijo. Un nodo que no tiene nodo padre se llama nodo raíz.\n"+
                    "Los árboles se utilizan en una amplia variedad de aplicaciones en programación, como la representación de la estructura jerárquica de un directorio de archivos en un sistema operativo, la representación de la estructura de una página web en HTML, la implementación de algoritmos de búsqueda binaria y la representación de relaciones jerárquicas en una organización.\n"
                    "Los árboles se pueden implementar en diferentes lenguajes de programación utilizando punteros y estructuras de datos. Algunos lenguajes de programación, como Python y Java, proporcionan bibliotecas integradas para trabajar con árboles."}
    
    Respuestas11 = {1: "En programación, un grafo es una estructura de datos no lineal que consta de un conjunto de nodos (también conocidos como vértices) y un conjunto de enlaces (también conocidos como aristas) que conectan los nodos. La estructura del grafo se parece a una red de conexiones en la vida real, como la red de carreteras, la red eléctrica o la red de comunicaciones.\n"+
                    "Los grafos se utilizan para representar relaciones complejas entre objetos o entidades en una variedad de aplicaciones en programación, como el modelado de redes sociales, el análisis de relaciones comerciales, la planificación de rutas de transporte y la representación de sistemas de información.\n"+
                    "Existen varios tipos de grafos, que se diferencian según la dirección y la ponderación de sus enlaces. Por ejemplo, un grafo dirigido es aquel en el que los enlaces tienen una dirección definida, mientras que un grafo no dirigido es aquel en el que los enlaces no tienen una dirección definida. Un grafo ponderado es aquel en el que cada enlace tiene un peso o valor asociado.\n"+
                    "Los grafos se pueden representar en programación utilizando matrices de adyacencia o listas de adyacencia. En una matriz de adyacencia, se utiliza una matriz bidimensional para representar los enlaces entre los nodos. En una lista de adyacencia, se utiliza una lista para cada nodo que enumera los nodos adyacentes a él.\n"+
                    "Los grafos también se pueden procesar utilizando algoritmos de búsqueda y recorrido, como el algoritmo de búsqueda en profundidad (DFS) y el algoritmo de búsqueda en amplitud (BFS). Estos algoritmos se utilizan para encontrar caminos entre nodos, identificar ciclos en el grafo y encontrar el árbol de expansión mínimo en un grafo ponderado.",
                    2: "En programación, un grafo es una estructura de datos no lineal que se compone de un conjunto de nodos (también conocidos como vértices) conectados por enlaces llamados aristas. Los grafos se utilizan para representar relaciones complejas entre objetos, como la conexión entre ciudades en un mapa, las relaciones entre usuarios en una red social o las dependencias entre tareas en un proyecto.\n"+
                    "Los grafos se pueden representar de dos maneras: mediante una matriz de adyacencia o mediante una lista de adyacencia. En una matriz de adyacencia, se utiliza una matriz para representar los nodos y las aristas del grafo. En una lista de adyacencia, se utiliza una lista enlazada para representar las aristas de cada nodo.\n"+
                    "Los grafos se pueden clasificar en diferentes tipos, según la forma en que están conectados sus nodos. Algunos ejemplos incluyen:\n"+
                    "-> Grafo dirigido: un grafo en el que las aristas tienen una dirección.\n"+
                    "-> Grafo no dirigido: un grafo en el que las aristas no tienen una dirección.\n"+
                    "-> Grafo ponderado: un grafo en el que cada arista tiene un peso o valor asociado.\n"+
                    "-> Grafo cíclico: un grafo en el que es posible seguir un camino desde un nodo y volver a él sin repetir aristas.\n"+
                    "-> Grafo acíclico: un grafo en el que no es posible seguir un camino desde un nodo y volver a él sin repetir aristas.\n"+
                    "Los grafos se utilizan en una amplia variedad de aplicaciones en programación, como el modelado de redes, la resolución de problemas de optimización y la implementación de algoritmos de búsqueda y ordenamiento.",
                    3: "En programación, un grafo es una estructura de datos no lineal que consta de un conjunto de nodos (vértices) conectados por enlaces (aristas). Un grafo se puede utilizar para representar relaciones complejas entre entidades, como redes de comunicación, relaciones sociales, rutas de viaje, y más.\n"+
                    "En un grafo, los vértices pueden estar conectados por uno o más bordes, que se pueden dirigir o no dirigir. Un borde dirigido es aquel que tiene una dirección definida, lo que significa que solo se puede viajar en una dirección, mientras que un borde no dirigido no tiene una dirección definida, lo que significa que se puede viajar en ambas direcciones.\n"+
                    "Existen varias formas de representar un grafo en programación, incluyendo listas de adyacencia, matrices de adyacencia y matrices de incidencia. Cada una de estas representaciones tiene sus propias ventajas y desventajas, y se pueden utilizar para diferentes tipos de problemas y algoritmos.\n"+
                    "Los grafos se utilizan en una amplia variedad de aplicaciones en programación, como la optimización de rutas, la minería de datos, la modelización de sistemas complejos y la resolución de problemas de optimización y planificación.\n"+
                    "Algunos algoritmos comunes que se utilizan con grafos incluyen el algoritmo de Dijkstra para encontrar la ruta más corta entre dos nodos, el algoritmo de Kruskal para encontrar el árbol de expansión mínimo de un grafo, y el algoritmo de búsqueda en profundidad y amplitud para recorrer un grafo."}
    
    Respuestas12 = {1: "En programación, una tabla hash (también conocida como mapa hash, diccionario o tabla de dispersión) es una estructura de datos que permite la búsqueda, inserción y eliminación de elementos de manera eficiente. En una tabla hash, los elementos se almacenan en una matriz (también llamada tabla) que se utiliza como una función hash para asignar cada elemento a una ubicación en la tabla.\n"+
                    "La función hash se encarga de transformar una clave (un valor único que identifica un elemento) en una posición en la tabla. Idealmente, la función hash debe asignar claves diferentes a ubicaciones diferentes en la tabla para evitar colisiones, que son cuando dos claves diferentes se asignan a la misma ubicación en la tabla. En caso de colisión, se utiliza una técnica de resolución de colisiones para determinar una nueva ubicación para el elemento.\n"+
                    "Las tablas hash se utilizan comúnmente para la implementación de estructuras de datos como conjuntos, mapas y tablas de símbolos en lenguajes de programación como Python, Java, C++ y otros. Las tablas hash son especialmente útiles para la búsqueda y recuperación de datos en grandes conjuntos de datos, ya que proporcionan una búsqueda en tiempo constante (O(1)) para la mayoría de las operaciones en el mejor caso y un rendimiento muy bueno en el peor caso. Sin embargo, la complejidad de la tabla hash depende en gran medida de la calidad de la función hash utilizada y de la cantidad de colisiones que se produzcan.",
                    2: "En programación, una tabla hash (o hash table en inglés) es una estructura de datos que permite almacenar y recuperar datos de manera eficiente utilizando una función de hash. Una función de hash toma un valor de entrada (como una cadena o un número) y devuelve una posición en la tabla hash donde se puede almacenar o buscar el valor correspondiente.\n"+
                    "La ventaja principal de una tabla hash es que la búsqueda y la inserción de elementos pueden realizarse en tiempo constante, en promedio, independientemente del tamaño de la tabla y el número de elementos almacenados. En contraste, las estructuras de datos lineales como los arreglos y las listas enlazadas requieren un tiempo proporcional al tamaño de la estructura para buscar o insertar elementos.\n"+
                    "Para implementar una tabla hash, se debe seleccionar una función de hash adecuada que distribuya los elementos de manera uniforme a través de la tabla. También se deben manejar las colisiones, que ocurren cuando dos elementos tienen la misma posición en la tabla hash. Hay varias estrategias para manejar las colisiones, como la resolución de colisiones mediante encadenamiento o la resolución de colisiones mediante sondeo.\n"+
                    "Las tablas hash se utilizan en una variedad de aplicaciones, como el almacenamiento y recuperación de datos en bases de datos, la implementación de diccionarios y mapas en lenguajes de programación y la realización de búsquedas en texto y otros tipos de datos.",
                    3: " En programación, una tabla hash (o hash table) es una estructura de datos que utiliza una función de hash para mapear claves a valores. Una función de hash es una función que toma una entrada (en este caso, una clave) y devuelve un valor numérico que representa esa entrada de manera única.\n"+
                    "La tabla hash utiliza esta función para asignar la clave a una posición en la tabla, lo que permite acceder rápidamente al valor correspondiente. Esto significa que las operaciones de búsqueda, inserción y eliminación en una tabla hash se pueden realizar en un tiempo constante promedio, independientemente del tamaño de la tabla.\n"+
                    "Las tablas hash se utilizan comúnmente para la implementación de diccionarios y conjuntos en lenguajes de programación. Por ejemplo, en Python, los diccionarios son implementados como tablas hash. También se utilizan para la búsqueda de datos en bases de datos, la indexación de archivos y la criptografía.\n"+
                    "Sin embargo, hay algunas consideraciones a tener en cuenta al utilizar tablas hash, como la elección de una función de hash adecuada, la colisión de claves (cuando dos claves diferentes se asignan a la misma posición en la tabla) y el factor de carga de la tabla (la relación entre el número de elementos almacenados y el tamaño de la tabla). Si no se manejan correctamente, estos factores pueden afectar negativamente el rendimiento de la tabla hash."}
    
    Respuestas13 = {1: "Tanto los arreglos como las listas enlazadas son estructuras de datos utilizadas para almacenar y manipular colecciones de elementos en programación. Sin embargo, hay algunas diferencias clave entre las dos estructuras:\n"+
                    "-> Representación en memoria: En un arreglo, los elementos se almacenan en ubicaciones contiguas de memoria, mientras que en una lista enlazada, los elementos se almacenan en nodos que se enlazan entre sí utilizando punteros.\n"+
                    "-> Tamaño: En un arreglo, el tamaño se define al momento de la creación y no se puede cambiar después. En una lista enlazada, el tamaño puede cambiar dinámicamente mediante la adición o eliminación de nodos.\n"+
                    "-> Acceso a los elementos: En un arreglo, los elementos se pueden acceder mediante un índice que indica la posición del elemento en la estructura. En una lista enlazada, se debe recorrer la lista secuencialmente para acceder a un elemento específico.\n"+
                    "-> Inserción y eliminación de elementos: En un arreglo, la inserción y eliminación de elementos en posiciones intermedias puede ser costosa, ya que implica mover todos los elementos posteriores hacia la derecha o hacia la izquierda para hacer espacio o llenar el espacio vacío. En una lista enlazada, la inserción y eliminación de nodos se puede realizar de manera eficiente en cualquier posición.\n"+
                    "En resumen, los arreglos son estructuras de datos estáticas que permiten un acceso rápido a los elementos mediante índices, mientras que las listas enlazadas son estructuras de datos dinámicas que permiten una inserción y eliminación eficiente de elementos en cualquier posición, pero que requieren un recorrido secuencial para acceder a los elementos.",
                    2: "La principal diferencia entre un arreglo y una lista enlazada es la forma en que se almacenan y acceden a los datos.\n"+
                    "Un arreglo es una estructura de datos lineal que almacena un conjunto de elementos de manera contigua en memoria. Cada elemento del arreglo se identifica mediante un índice numérico que indica su posición en el arreglo. La ventaja de un arreglo es que permite el acceso aleatorio a cualquier elemento en tiempo constante, lo que significa que se puede acceder a cualquier elemento del arreglo directamente a través de su índice. Sin embargo, el tamaño del arreglo se fija en tiempo de compilación, lo que significa que no se puede agregar o eliminar elementos dinámicamente.\n"+
                    "Por otro lado, una lista enlazada es una estructura de datos en la que cada elemento (nodo) almacena un valor y un puntero (enlace) al siguiente elemento en la lista. Los elementos de una lista enlazada no se almacenan de manera contigua en memoria, sino que pueden estar dispersos en diferentes lugares de la memoria. La ventaja de una lista enlazada es que se pueden agregar o eliminar elementos dinámicamente en tiempo constante, ya que solo es necesario cambiar los punteros a los nodos adyacentes. Sin embargo, el acceso aleatorio a un elemento en una lista enlazada requiere recorrer la lista desde el principio hasta el elemento deseado, lo que puede llevar tiempo lineal.\n"+
                    "En resumen, un arreglo se utiliza cuando se necesita acceso aleatorio rápido a los elementos de la estructura y se conoce de antemano el tamaño de la estructura, mientras que una lista enlazada se utiliza cuando se necesita agregar o eliminar elementos dinámicamente y el acceso aleatorio no es una consideración importante.",
                    3: "La principal diferencia entre un arreglo y una lista enlazada es la forma en que los elementos se almacenan y se acceden a ellos en memoria.\n"+
                    "Un arreglo es una estructura de datos lineal que almacena un conjunto de elementos del mismo tipo en una secuencia contigua de posiciones de memoria. Los elementos se acceden a través de un índice que indica la posición del elemento en el arreglo. Los arreglos tienen un tamaño fijo y se pueden acceder y modificar rápidamente en tiempo constante, lo que los hace eficientes para operaciones de acceso aleatorio y recorrido secuencial.\n"+
                    "Por otro lado, una lista enlazada es una estructura de datos no lineal que consta de un conjunto de nodos enlazados, donde cada nodo almacena un elemento y un puntero al siguiente nodo en la lista. Los nodos no se almacenan de forma contigua en memoria y no hay un índice que indique la posición de un elemento en la lista. Los elementos se acceden recorriendo la lista desde el primer nodo hasta el último. Las listas enlazadas tienen un tamaño dinámico y se pueden insertar y eliminar elementos de manera eficiente, lo que las hace útiles para operaciones de inserción y eliminación en el medio de la lista.\n"+
                    "En resumen, la principal diferencia entre un arreglo y una lista enlazada es la forma en que se almacenan y se acceden a los elementos en memoria. Los arreglos son eficientes para el acceso aleatorio y el recorrido secuencial, mientras que las listas enlazadas son útiles para la inserción y eliminación de elementos en el medio de la lista."}
    
    Respuestas14 = {1: "Una estructura de datos dinámica es una estructura de datos que puede crecer o disminuir de tamaño durante la ejecución del programa, según sea necesario. Esto significa que su tamaño no está fijo y puede cambiar en tiempo de ejecución. Ejemplos de estructuras de datos dinámicas incluyen las listas enlazadas, las pilas, las colas y las tablas hash.\n"+
                    "Las ventajas de las estructuras de datos dinámicas son:\n"+
                    "-> Flexibilidad en la asignación de memoria: Las estructuras de datos dinámicas permiten una asignación de memoria flexible en tiempo de ejecución, lo que significa que se puede asignar más memoria a la estructura de datos cuando se necesita y liberar la memoria no utilizada.\n"+
                    "-> Eficiencia en el uso de memoria: Las estructuras de datos dinámicas utilizan la cantidad justa de memoria que se necesita en tiempo de ejecución, lo que significa que no hay desperdicio de memoria y el uso de memoria se optimiza.\n"+
                    "-> Capacidad de crecimiento: Las estructuras de datos dinámicas pueden crecer o disminuir de tamaño según sea necesario, lo que significa que se pueden adaptar a diferentes situaciones y requisitos de memoria.\n"+
                    "-> 	Operaciones eficientes: Las estructuras de datos dinámicas ofrecen operaciones eficientes de inserción, eliminación y búsqueda de elementos, lo que significa que se pueden manejar grandes cantidades de datos de manera eficiente.\n"+
                    "En resumen, las estructuras de datos dinámicas son flexibles, eficientes en el uso de memoria, adaptables y ofrecen operaciones eficientes, lo que las hace muy útiles en la programación y el manejo de grandes cantidades de datos.",
                    2: "Una estructura de datos dinámica es aquella cuyo tamaño puede cambiar durante la ejecución del programa. Esto significa que se puede agregar o eliminar elementos de la estructura en tiempo de ejecución según sea necesario, lo que proporciona mayor flexibilidad y eficiencia en ciertas operaciones.\n"+
                    "Las ventajas de las estructuras de datos dinámicas incluyen:\n"+
                    "-> Eficiencia: Las estructuras de datos dinámicas permiten agregar o eliminar elementos en tiempo constante o logarítmico, lo que es más eficiente que tener que copiar toda la estructura de datos para agregar o eliminar elementos en una posición específica.\n"+
                    "-> Uso eficiente de la memoria: Las estructuras de datos dinámicas utilizan solo la cantidad de memoria necesaria en un momento dado, en lugar de asignar una cantidad fija de memoria que puede no ser utilizada por completo. Esto permite que el programa utilice la memoria de manera más eficiente y evita la pérdida de memoria.\n"+
                    "-> Flexibilidad: Las estructuras de datos dinámicas permiten que el tamaño de la estructura de datos se ajuste según sea necesario, lo que las hace útiles para situaciones en las que el tamaño de los datos puede variar o no se conoce de antemano.\n"+
                    "-> Escalabilidad: Las estructuras de datos dinámicas son escalables y pueden manejar grandes cantidades de datos sin afectar el rendimiento del programa.\n"+
                    "Ejemplos de estructuras de datos dinámicas incluyen listas enlazadas, árboles, colas, pilas y tablas hash, entre otras.",
                    3: "Una estructura de datos dinámica es una estructura que puede cambiar de tamaño durante la ejecución del programa. A diferencia de las estructuras de datos estáticas, como los arreglos, que tienen un tamaño fijo y se asignan en tiempo de compilación, las estructuras de datos dinámicas se asignan en tiempo de ejecución y pueden crecer o disminuir de tamaño según sea necesario.\n"+
                    "Las ventajas de las estructuras de datos dinámicas incluyen:\n"+
                    "-> Flexibilidad en el tamaño: Las estructuras de datos dinámicas pueden crecer o disminuir de tamaño durante la ejecución del programa, lo que permite una mayor flexibilidad en la gestión de los datos.\n"+
                    "-> Ahorro de memoria: Las estructuras de datos dinámicas pueden asignar memoria según sea necesario, lo que permite ahorrar memoria en comparación con las estructuras de datos estáticas, que deben reservar toda la memoria necesaria de antemano.\n"+
                    "-> Eficiencia en la inserción y eliminación de elementos: Las estructuras de datos dinámicas, como las listas enlazadas, son eficientes para la inserción y eliminación de elementos en cualquier posición, mientras que los arreglos estáticos requieren copiar grandes cantidades de datos si se desea insertar o eliminar un elemento en una posición intermedia.\n"+
                    "-> Facilidad de implementación: Las estructuras de datos dinámicas son fáciles de implementar y modificar, lo que las hace ideales para aplicaciones que requieren una gestión dinámica de los datos.\n"+
                    "En resumen, las estructuras de datos dinámicas ofrecen flexibilidad en el tamaño, ahorro de memoria, eficiencia en la inserción y eliminación de elementos, y facilidad de implementación, lo que las hace una opción popular en la programación de aplicaciones que requieren una gestión dinámica de los datos."}
    
    Respuestas15 = {1: "La principal diferencia entre una pila y una cola es el orden en que los elementos son insertados y eliminados de la estructura.\n"+
                    "Una pila es una estructura de datos lineal que sigue la regla de \"último en entrar, primero en salir\" (LIFO, por sus siglas en inglés). Esto significa que el último elemento que se inserta en la pila es el primero en salir. La inserción de elementos se realiza en la parte superior de la pila, y la eliminación de elementos también se realiza desde la parte superior. Las operaciones principales en una pila son push (para insertar un elemento) y pop (para eliminar un elemento).\n"+
                    "Por otro lado, una cola es una estructura de datos lineal que sigue la regla de \"primero en entrar, primero en salir\" (FIFO, por sus siglas en inglés). Esto significa que el primer elemento que se inserta en la cola es el primero en salir. La inserción de elementos se realiza al final de la cola, y la eliminación de elementos se realiza desde el frente de la cola. Las operaciones principales en una cola son enqueue (para insertar un elemento) y dequeue (para eliminar un elemento).\n"+
                    "En resumen, la principal diferencia entre una pila y una cola es el orden en que se insertan y eliminan los elementos. Una pila sigue la regla LIFO (último en entrar, primero en salir) mientras que una cola sigue la regla FIFO (primero en entrar, primero en salir).",
                    2: "La principal diferencia entre una pila y una cola es la forma en que los elementos son eliminados de la estructura.\n"+
                    "Una pila es una estructura de datos lineal que permite agregar y eliminar elementos en la parte superior de la pila, también conocido como el extremo \"top\". Los elementos se agregan en la parte superior de la pila y se eliminan de la misma manera, es decir, el último elemento que se agrega es el primero en eliminarse (LIFO, Last In First Out). Una pila se asemeja a una pila de platos, donde el último plato que se coloca en la pila es el primero en ser retirado.\n"+
                    "Por otro lado, una cola es también una estructura de datos lineal que permite agregar y eliminar elementos, pero en este caso se hace por los extremos opuestos. Los elementos se agregan al final de la cola y se eliminan del principio de la misma (FIFO, First In First Out). Una cola se asemeja a una línea de personas esperando para ser atendidas, donde la primera persona en llegar a la cola es la primera en ser atendida.\n"+
                    "En resumen, la principal diferencia entre una pila y una cola es el orden en que los elementos son eliminados de la estructura. Una pila sigue el principio LIFO (Last In First Out) mientras que una cola sigue el principio FIFO (First In First Out).",
                    3: "La principal diferencia entre una pila y una cola es la forma en que se acceden y se eliminan los elementos de la estructura de datos.\n"+
                    "Una pila es una estructura de datos lineal que utiliza el principio \"LIFO\" (last-in, first-out), lo que significa que el último elemento que se inserta en la pila es el primero en salir. Los elementos se agregan y se eliminan de la pila por un solo extremo llamado la cima o el tope de la pila. Cuando se elimina un elemento de la pila, se elimina el elemento que está en la cima de la pila.\n"+
                    "Por otro lado, una cola es una estructura de datos lineal que utiliza el principio \"FIFO\" (first-in, first-out), lo que significa que el primer elemento que se inserta en la cola es el primero en salir. Los elementos se agregan al final de la cola y se eliminan por el otro extremo, llamado el frente o la cabeza de la cola. Cuando se elimina un elemento de la cola, se elimina el elemento que está en el frente de la cola.\n"+
                    "En resumen, la principal diferencia entre una pila y una cola es el orden en que se acceden y se eliminan los elementos. Una pila sigue el principio \"LIFO\" y se accede y se elimina por la cima de la pila, mientras que una cola sigue el principio \"FIFO\" y se accede y se elimina por el frente de la cola."}
    
    Respuestas16 = {1: "Un árbol AVL es una estructura de datos de árbol binario que se utiliza para almacenar un conjunto ordenado de elementos. En un árbol AVL, la altura de los subárboles izquierdo y derecho de cada nodo difiere en no más de 1, lo que garantiza que el árbol esté siempre equilibrado. El nombre AVL se deriva de los apellidos de los creadores de la estructura, Adel'son-Velsky y Landis.\n"+
                    "La principal ventaja de los árboles AVL es que garantizan un tiempo de búsqueda y operaciones de inserción y eliminación de elementos muy eficiente, ya que mantienen el árbol siempre equilibrado. La altura de un árbol AVL está en el orden de log(n), donde n es el número de elementos en el árbol, lo que significa que el tiempo de búsqueda, inserción y eliminación de elementos también está en el orden de log(n). Esta eficiencia es muy valiosa para aplicaciones que requieren una alta velocidad de procesamiento, como las bases de datos o sistemas de búsqueda.\n"+
                    "Además, los árboles AVL también son útiles para aplicaciones que requieren una gestión dinámica de los datos, ya que son capaces de ajustar automáticamente su estructura para mantener el equilibrio. Esto significa que no se requiere intervención manual para mantener el árbol equilibrado, lo que permite una gestión más eficiente de los datos.\n"+
                    "En resumen, la principal ventaja de los árboles AVL es que garantizan un tiempo de búsqueda y operaciones de inserción y eliminación de elementos muy eficiente gracias a su estructura equilibrada. También son útiles para aplicaciones que requieren una gestión dinámica de los datos, ya que ajustan automáticamente su estructura para mantener el equilibrio.",
                    2: "Un árbol AVL es un tipo de árbol binario de búsqueda balanceado en el que la altura de los subárboles izquierdo y derecho de cualquier nodo difiere como máximo en uno. Esto garantiza que el árbol tenga una altura equilibrada, lo que se traduce en tiempos de búsqueda, inserción y eliminación de elementos más eficientes que en un árbol binario de búsqueda no balanceado.\n"+
                    "La principal ventaja de los árboles AVL es que garantizan un tiempo de búsqueda, inserción y eliminación de elementos de O(log n) en el peor de los casos, donde \"n\" es el número de elementos en el árbol. En contraste, en un árbol binario de búsqueda no balanceado, el tiempo de búsqueda, inserción y eliminación de elementos puede ser O(n) en el peor de los casos, donde \"n\" es el número de elementos en el árbol.\n"+
                    "Los árboles AVL se mantienen balanceados mediante una serie de rotaciones que se realizan automáticamente después de cualquier inserción o eliminación de elementos. Esto asegura que el árbol esté siempre equilibrado y que los tiempos de búsqueda, inserción y eliminación de elementos sean óptimos.\n"+
                    "En resumen, la principal ventaja de los árboles AVL es que garantizan un tiempo de búsqueda, inserción y eliminación de elementos de O(log n) en el peor de los casos, lo que los hace más eficientes que los árboles binarios de búsqueda no balanceados en términos de tiempo de ejecución.",
                    3: "Un árbol AVL es una estructura de datos de árbol binario auto-balanceado que se utiliza para almacenar y buscar elementos en una colección de datos. Fue inventado por los matemáticos rusos Adelson-Velsky y Landis, de ahí su nombre. La principal ventaja de un árbol AVL es que mantiene automáticamente el equilibrio de la estructura del árbol, lo que garantiza que el tiempo de búsqueda, inserción y eliminación de elementos sea siempre logarítmico y no se degradará a medida que aumente el tamaño de la estructura de datos.\n"+
                    "En un árbol AVL, cada nodo tiene un factor de equilibrio que indica la diferencia entre las alturas de su subárbol derecho y su subárbol izquierdo. El factor de equilibrio debe estar en el rango {-1, 0, 1} para mantener el equilibrio del árbol. Si la inserción o eliminación de un elemento provoca un desequilibrio en el árbol, se realiza una o más rotaciones en el árbol para restaurar el equilibrio. Una rotación es una operación en la que se reorganizan los nodos del árbol para mantener el equilibrio y conservar el orden de los elementos.\n"+
                    "La principal ventaja de un árbol AVL es que garantiza que el tiempo de búsqueda, inserción y eliminación de elementos sea siempre logarítmico y no se degrade a medida que aumenta el tamaño de la estructura de datos. Esto es especialmente importante en aplicaciones en tiempo real y en aplicaciones de bases de datos, donde se requiere una respuesta rápida y eficiente. Además, los árboles AVL son eficientes en términos de memoria, ya que no requieren almacenar información adicional para mantener el equilibrio."}
    
    Respuestas17 = {1: "La diferencia principal entre un árbol binario y un árbol binario de búsqueda (BST, por sus siglas en inglés) es que el árbol binario de búsqueda tiene una propiedad adicional que lo hace más útil en la búsqueda y ordenación de elementos.\n"+
                    "Un árbol binario es una estructura de datos en la que cada nodo tiene como máximo dos hijos. No tiene ninguna restricción sobre cómo se organizan los nodos en el árbol, por lo que puede haber muchos árboles binarios diferentes que contengan los mismos elementos.\n"+
                    "Por otro lado, un árbol binario de búsqueda es un árbol binario especial en el que cada nodo tiene un valor que es mayor que todos los valores en su subárbol izquierdo y menor que todos los valores en su subárbol derecho. Esta propiedad hace que la búsqueda, inserción y eliminación de elementos en un árbol binario de búsqueda sea mucho más eficiente que en un árbol binario regular, ya que se puede descartar rápidamente la mitad del árbol en cada operación.\n"+
                    "En resumen, la principal diferencia entre un árbol binario y un árbol binario de búsqueda es que el árbol binario de búsqueda tiene una propiedad adicional que lo hace más útil en la búsqueda y ordenación de elementos.",
                    2: "La principal diferencia entre un árbol binario y un árbol binario de búsqueda es que el árbol binario de búsqueda garantiza que cada nodo tenga un valor mayor que los nodos de su subárbol izquierdo y un valor menor que los nodos de su subárbol derecho. En otras palabras, los árboles binarios de búsqueda están organizados de tal manera que los elementos se pueden buscar, insertar y eliminar de manera eficiente.\n"+
                    "Por otro lado, un árbol binario puede estar organizado de cualquier manera, sin seguir de todos modos un orden específico para los valores de los nodos. Los árboles binarios son útiles para estructurar jerárquica, como árboles de archivos, árboles genealógicos, entre otros, pero no garantizan una búsqueda eficiente, inserción y eliminación de elementos\n"+
                    "En resumen, mientras que los árboles binarios pueden ser utilizados para estructurar información jerárquica, los árboles binarios de búsqueda tienen la ventaja de garantizar un ordenamiento de los elementos, lo que permite una búsqueda más eficiente.",
                    3: "Un árbol binario es una estructura de datos de árbol en la que cada nodo tiene como máximo dos hijos: un hijo izquierdo y un hijo derecho. Cada nodo puede contener un valor o una referencia a un objeto.\n"+
                    "Por otro lado, un árbol binario de búsqueda (BST) es un tipo especial de árbol binario en el que los valores de los nodos están organizados de tal manera que el valor en cada nodo es mayor que todos los en su subárbol izquierdo y menor que todos los valores en su subárbol derecho.\n"+
                    "En otras palabras, un árbol binario de búsqueda garantiza que la búsqueda, inserción y eliminación de un elemento se realice de manera eficiente y en tiempo logarítmico. Al buscar un elemento en un árbol binario de búsqueda, se comienza en la raíz del árbol y se compara el valor del nodo actual con el valor buscado. Si el valor buscado es menor, se desciende al subárbol izquierdo; si es mayor, se cae al subárbol derecho; si es igual, se ha encontrado el elemento.\n"+
                    "En resumen, la principal diferencia entre un árbol binario y un árbol binario de búsqueda es que el último está para tener una estructura diseñada ordenadamente que permite realizar operaciones de búsqueda, inserción y eliminación de elementos de manera eficiente, mientras que un árbol binario no tiene esta propiedad."}
    
    Respuestas18 = {1: "Las listas enlazadas son útiles para insertar y eliminar elementos en tiempo constante debido a su estructura de datos y su forma de almacenar los elementos.\n"+
                    "En una lista enlazada, cada elemento está formado por un nodo que contiene un valor y un puntero que apunta al siguiente nodo en la lista. Al insertar o eliminar un elemento en una lista enlazada, solo es necesario actualizar los punteros de los nodos auxiliares, lo que se puede hacer en tiempo constante. Esto se debe a que no es necesario mover todos los elementos de la lista, como sí sucede en un arreglo, donde al insertar o eliminar un elemento se deben reorganizar todos los elementos posteriores al elemento modificado.\n"+
                    "Además, las listas enlazadas pueden crecer o reducirse dinámicamente según sea necesario, lo que significa que no es necesario reservar una cantidad fija de memoria de antemano como sí sucede con los arreglos. Esto es especialmente útil en situaciones donde el tamaño de la lista puede cambiar con frecuencia.\n"+
                    "En resumen, las listas enlazadas son útiles para insertar y eliminar elementos en tiempo constante debido a su estructura de datos y su capacidad para crecer o reducirse dinámicamente sin la necesidad de reorganizar todos los elementos en la lista.",
                    2: "Las listas enlazadas son útiles para insertar y eliminar elementos en tiempo constante porque la inserción y eliminación en una lista enlazada no requiere mover todos los elementos del arreglo como en el caso de un arreglo estático. En cambio, solo se necesita ajustar los punteros que apuntan a los nodos vecinos para insertar o eliminar un nodo en la lista enlazada.\n"+
                    "En una lista enlazada, cada nodo tiene un puntero que apunta al siguiente nodo en la lista. Al insertar un nuevo nodo en la lista, simplemente se crea un nuevo nodo y se ajustan los punteros del nodo anterior y el siguiente nodo para apuntar al nuevo nodo. De esta manera, la inserción se realiza en tiempo constante, independientemente del tamaño de la lista\n"+
                    "Lo mismo ocurre al eliminar un nodo en la lista enlazada. Solo se necesitan ajustar los punteros del nodo anterior y el siguiente nodo para saltar sobre el nodo que se está eliminando. Por lo tanto, la eliminación también se realiza en tiempo constante\n"+
                    "En resumen, las listas enlazadas son útiles para insertar y eliminar elementos en tiempo constante porque aprovechan la estructura de punteros de los nodos para realizar inserciones y eliminaciones sin tener que mover todos los elementos del arreglo, como se hace en los arreglos estáticos.",
                    3: "Las listas enlazadas son útiles para insertar y eliminar elementos en tiempo constante porque no requieren un reordenamiento de los elementos en la estructura de datos como sucede con los arreglos.\n"+
                    "En una lista enlazada, cada elemento (nodo) contiene un puntero que apunta al siguiente nodo en la lista, formando una cadena enlazada. Para insertar un nuevo elemento en la lista, simplemente se crea un nuevo nodo y se actualizan los punteros del nodo anterior y del siguiente para que apunten al nuevo nodo. De esta manera, se puede insertar un nuevo elemento en cualquier posición de la lista en tiempo constante O(1), independientemente del tamaño de la lista.\n"+
                    "Para eliminar un elemento en una lista enlazada, se actualizarán los punteros del nodo anterior y del siguiente para saltar el nodo que se va a eliminar. Esto también se puede hacer en tiempo constante O(1), ya que solo se necesitan actualizar dos punteros para eliminar el nodo\n"+
                    "En resumen, las listas enlazadas son útiles para insertar y eliminar elementos en tiempo constante porque no se requiere un reordenamiento de los elementos en la estructura de datos, lo que las hace más eficientes que otras estructuras de datos como los arreglos."}
    
    Respuestas19 = {1: "La estructura de datos adecuada para representar un árbol genealógico es un árbol familiar o árbol genealógico, que es un tipo de árbol en el que cada nodo representa a una persona y los nodos hijos a sus descendientes. En un árbol genealógico, cada nodo tiene un puntero que apunta a su padre y otro puntero que apunta a su primer hijo.\n"+
                    "Cada nodo en el árbol genealógico contiene información sobre la persona, como su nombre, fecha de nacimiento, fecha de fallecimiento, género, etc. Además, el árbol puede contener información adicional, como el lugar de origen de la familia o relaciones entre los miembros de la familia.\n"+
                    "En un árbol genealógico, los nodos raíz representan a los antepasados más antiguos, y los nodos hoja representan a los miembros más jóvenes de la familia. La estructura del árbol genealógico permite representar de manera clara y concisa las relaciones de parentesco entre los miembros de la familia y la información histórica de la familia\n"+
                    "En resumen, el árbol genealógico es la estructura de datos adecuada para representar un árbol genealógico, ya que permite organizar y representar de manera eficiente las relaciones de parentesco entre los miembros de la familia y la información histórica de la familia.",
                    2: "La estructura de datos adecuada para representar un árbol genealógico es un árbol binario, también conocido como árbol general. En este tipo de árbol, cada nodo puede tener un número arbitrario de hijos, lo que lo hace adecuado para representar las relaciones familiares en un árbol genealógico.\n"+
                    "En un árbol genealógico, cada persona se representa como un nodo en el árbol, y cada nodo tiene uno o más hijos que representan a sus descendientes. Además, cada nodo puede tener un puntero a su padre, lo que permite navegar por el árbol tanto hacia arriba (padres, abuelos, etc.) como hacia abajo (hijos, nietos, etc.).\n"+
                    "En resumen, un árbol n-ario es la estructura de datos adecuada para representar un árbol genealógico, ya que permite representar las relaciones familiares complejas y proporciona una forma eficiente de acceder y recorrer la información en el árbol",
                    3: "La estructura de datos adecuada para representar un árbol genealógico es un árbol genealógico, que es un tipo especial de árbol que representa las relaciones familiares entre personas. Cada nodo en el árbol genealógico representa a una persona y tiene una referencia a sus padres (si se conocen) ya sus hijos (si los tiene).\n"+
                    "En un árbol genealógico, el nodo raíz representa al ancestro más antiguo, y cada nivel del árbol representa una generación. Por lo general, los nodos se organizan de tal manera que el padre se encuentra en el nivel superior y los hijos en el nivel inferior.\n"+
                    "Cada nodo en el árbol genealógico puede contener información adicional sobre la persona, como su nombre, fecha de nacimiento, fecha de fallecimiento, ocupación, etc. Además, el árbol genealógico puede incluir referencias a otros árboles genealógicos, en caso de que haya ramas separadas de la familia.\n"+
                    "En resumen, el árbol genealógico es la estructura de datos adecuada para representar un árbol genealógico, ya que permite organizar y representar las relaciones familiares de manera clara y jerárquica."}
    
    Respuestas20 = {1: "La complejidad temporal de la operación de búsqueda en un árbol binario depende de la altura del árbol y puede variar de O(1) en el mejor caso, hasta O(n) en el peor caso, donde n es el número de nodos del árbol.\n"+
                    "En el mejor caso, la complejidad temporal de la búsqueda en un árbol binario es O(1), si el elemento buscado se encuentra en la raíz del árbol.\n"+
                    "En el peor caso, la complejidad temporal de la búsqueda en un árbol binario es O(n), si el árbol es un árbol degenerado (es decir, cada nodo tiene solo un hijo) y el elemento buscado se encuentra en el último nivel del árbol.\n"+
                    "En promedio, la complejidad temporal de la búsqueda en un árbol binario es O(log n), donde n es el número de nodos del árbol, ya que cada comparación en la búsqueda elimina la mitad de los nodos que quedan por buscar. Esto se debe a que un árbol binario equilibrado tiene una altura de log2(n+1) en el peor caso, lo que significa que el número de comparaciones necesarias para encontrar un elemento en el árbol es proporcional a log2(n+1).\n"+
                    "Es importante destacar que la complejidad temporal de la búsqueda en un árbol binario puede mejorar significativamente si se utiliza un árbol binario de búsqueda balanceado, como un árbol AVL o un árbol Rojo-Negro, ya que garantizan una altura máxima de O(log n), independientemente de la distribución de los datos en el árbol.",
                    2: "La complejidad temporal de la operación de búsqueda en un árbol binario depende del número de nodos en el árbol y su altura. En el peor de los casos, cuando el árbol es un árbol binario degenerado (es decir, una lista enlazada), la complejidad temporal de la búsqueda será O(n), donde n es el número de nodos en el árbol.\n"+
                    "Sin embargo, en un árbol binario bien balanceado, como un árbol binario de búsqueda AVL, la altura del árbol será logarítmica en función del número de nodos. En este caso, la complejidad temporal de la búsqueda será O(log n), donde n es el número de nodos en el árbol.\n"+
                    "La complejidad temporal de la operación de búsqueda en un árbol binario también puede verse afectada por la implementación específica de la operación de búsqueda. Por ejemplo, en una búsqueda recursiva en un árbol binario, se puede agregar una sobrecarga adicional debido a las llamadas recursivas.",
                    3: "La complejidad temporal de la operación de búsqueda en un árbol binario depende del número de nodos en el árbol y de su altura. En el peor caso, donde el árbol está completamente desequilibrado y se comporta como una lista enlazada, la complejidad temporal de la búsqueda es O(n), donde n es el número de nodos en el árbol.\n"+
                    "Sin embargo, en el caso promedio, donde el árbol está equilibrado y su altura es logarítmica en relación al número de nodos, la complejidad temporal de la búsqueda es O(log n). Esto se debe a que en cada nivel del árbol, la cantidad de nodos se duplica, lo que permite descartar la mitad del árbol en cada iteración.\n"+
                    "En resumen, la complejidad temporal de la búsqueda en un árbol binario es O(n) en el peor caso y O(log n) en el caso promedio, lo que lo convierte en una estructura de datos eficiente para la búsqueda de elementos."}
    
    Respuestas21 = {1: "La complejidad temporal de la operación push y pop en una pila implementada con una lista enlazada depende del tamaño de la pila y de la posición del elemento que se va a insertar o eliminar.\n"+
                    "En una pila implementada con una lista enlazada, la operación push consiste en insertar un nuevo elemento en la parte superior de la pila, lo cual se realiza en tiempo constante O(1), ya que sólo es necesario actualizar el puntero que apunta al último elemento agregado.\n"+
                    "Por otro lado, la operación pop consiste en eliminar el último elemento insertado en la pila, lo cual también se realiza en tiempo constante O(1), ya que sólo es necesario actualizar el puntero que apunta al último elemento eliminado.\n"+
                    "En resumen, la complejidad temporal de las operaciones push y pop en una pila implementada con una lista enlazada es O(1), lo que la convierte en una estructura de datos eficiente para la inserción y eliminación de elementos en la parte superior de la pila.",
                    2: "La complejidad temporal de la operación push y pop en una pila implementada con una lista enlazada es O(1), es decir, constante.\n"+
                    "Cuando se realiza la operación push en una pila implementada con una lista enlazada, simplemente se agrega un nuevo elemento al inicio de la lista enlazada. Esto implica actualizar el puntero que apunta a la cabeza de la lista, lo cual se realiza en tiempo constante.\n"+
                    "Por otro lado, cuando se realiza la operación pop en una pila implementada con una lista enlazada, se elimina el elemento que se encuentra en el inicio de la lista enlazada y se actualiza el puntero que apunta a la cabeza de la lista. Esto también se realiza en tiempo constante.\n"+
                    "En resumen, la complejidad temporal de la operación push y pop en una pila implementada con una lista enlazada es O(1), lo que la convierte en una estructura de datos eficiente para operaciones de apilamiento y desapilamiento.",
                    3: "En una pila implementada con una lista enlazada, la complejidad temporal de la operación push (agregar un elemento a la pila) y la operación pop (eliminar el elemento superior de la pila) es O(1), es decir, constante.\n"+
                    "Esto se debe a que la lista enlazada permite agregar o eliminar elementos en la cabeza de la lista en tiempo constante, sin importar el tamaño de la lista. En otras palabras, no es necesario recorrer toda la lista para realizar estas operaciones, ya que la cabeza de la lista se actualiza directamente.\n"+
                    "Por lo tanto, una pila implementada con una lista enlazada es una estructura de datos eficiente para las operaciones de push y pop, lo que la hace útil en una variedad de situaciones donde se requiere el uso de una pila."}
    
    Respuestas22 = {1: "En una pila y una cola implementadas con un arreglo, la complejidad de tiempo de la operación de inserción (push para pila, enqueue para cola) y eliminación (pop para pila, dequeue para cola) depende de la posición del elemento que se está agregando o eliminando en el arreglo.\n"+
                    "En el caso de una pila, las operaciones de inserción y eliminación se realizan en la cima de la pila, es decir, en la posición más alta del arreglo. Por lo tanto, la complejidad de tiempo de ambas operaciones es O(1), es decir, constante.\n"+
                    "En el caso de una cola, las operaciones de inserción se realizan en la parte posterior de la cola y las operaciones de eliminación se realizan en la parte delantera de la cola. Si el arreglo se implementa como un círculo (usando una técnica conocida como \"buffer circular\"), entonces las operaciones de inserción y eliminación se pueden realizar en tiempo constante, ya que la posición de la parte delantera y trasera de la cola se actualiza simplemente como un índice que se mueve de forma circular en el arreglo. En este caso, la complejidad de tiempo de ambas operaciones es O(1).\n"+
                    "Sin embargo, si el arreglo no se implementa como un buffer circular, la operación de eliminación en una cola puede ser costosa en el peor de los casos, ya que puede requerir mover todos los elementos del arreglo para actualizar sus índices. En este caso, la complejidad de tiempo de la operación de eliminación sería O(n), donde n es el tamaño de la cola.\n"+
                    "En resumen, la complejidad de tiempo de inserción y eliminación en una pila es O(1) y en una cola puede ser O(1) en el mejor caso (cuando se usa un buffer circular) y O(n) en el peor caso (cuando no se usa un buffer circular).",
                    2: "La complejidad temporal de las operaciones de inserción y eliminación en una pila y una cola dependen de cómo estén implementadas.\n"+
                    "En una pila implementada con un arreglo, la inserción y eliminación de elementos en la pila tienen una complejidad temporal de O(1) si se realiza en la parte superior de la pila, ya que no hay necesidad de mover ningún elemento en el arreglo. Sin embargo, si se realiza en cualquier otra posición del arreglo, la complejidad temporal será O(n), ya que se deben desplazar los elementos hacia arriba o hacia abajo para abrir espacio o llenar el espacio vacío.\n"+
                    "En una pila implementada con una lista enlazada, como se mencionó anteriormente, la inserción y eliminación de elementos en la pila tienen una complejidad temporal de O(1), ya que se agregan o eliminan elementos en la cabeza de la lista.\n"+
                    "En una cola implementada con un arreglo, la inserción y eliminación de elementos en la cola tienen una complejidad temporal de O(1) si se realizan en la parte trasera de la cola y en la parte delantera de la cola, respectivamente. Sin embargo, si se realiza en cualquier otra posición del arreglo, la complejidad temporal será O(n), ya que se deben desplazar los elementos hacia arriba o hacia abajo para abrir espacio o llenar el espacio vacío.\n"+
                    "En una cola implementada con una lista enlazada, la inserción de elementos en la cola tiene una complejidad temporal de O(1), ya que se agrega un elemento al final de la lista enlazada. La eliminación de elementos en la cola también tiene una complejidad temporal de O(1) si se mantiene un puntero al inicio de la lista enlazada, lo que permite eliminar el primer elemento de la cola en tiempo constante.\n"+
                    "En resumen, la complejidad temporal de las operaciones de inserción y eliminación en una pila y una cola dependen de cómo estén implementadas, pero en general, una pila o cola implementada con una lista enlazada es más eficiente que una implementada con un arreglo para estas operaciones.",
                    3: "En una pila, la operación de inserción (push) y eliminación (pop) se realiza en tiempo constante O(1), ya que ambas operaciones se realizan en la parte superior de la pila. Esto se debe a que la pila sigue el principio LIFO (último en entrar, primero en salir), por lo que siempre se trabaja con el último elemento agregado a la pila.\n"+
                    "En una cola, la operación de inserción (enqueue) se realiza en tiempo constante O(1), ya que el nuevo elemento se agrega al final de la cola, mientras que la operación de eliminación (dequeue) se realiza en tiempo lineal O(n), donde n es el número de elementos en la cola. Esto se debe a que el primer elemento de la cola debe ser eliminado y la cola debe ser actualizada, lo que requiere reorganizar todos los elementos restantes en la cola.\n"+
                    "En resumen, la complejidad de tiempo de las operaciones de inserción y eliminación en una pila es O(1), mientras que la complejidad de la operación de eliminación en una cola es O(n) y la complejidad de la operación de inserción es O(1)."}
    
    Respuestas23 = {1: "Las estructuras de datos recursivas en programación son aquellas estructuras que se definen en términos de sí mismas. Es decir, una estructura de datos recursiva contiene uno o más elementos que son de la misma estructura de datos. En otras palabras, la estructura se define en términos de una versión más pequeña o más simple de sí misma.\n"+
                    "Un ejemplo común de una estructura de datos recursiva es el árbol binario, donde cada nodo puede tener cero, uno o dos hijos, cada uno de los cuales es también un árbol binario. Otro ejemplo común es la lista enlazada, donde cada elemento tiene un puntero al siguiente elemento de la lista, que es también un elemento de la lista enlazada.\n"+
                    "Las estructuras de datos recursivas son útiles porque permiten la creación de estructuras de datos complejas y dinámicas de manera eficiente. Además, la recursividad también se puede utilizar para implementar algoritmos que operan en estas estructuras de datos de manera más clara y concisa.",
                    2: "Las estructuras de datos recursivas en programación son aquellas que se definen en términos de sí mismas. En otras palabras, una estructura de datos recursiva contiene uno o más elementos de la misma estructura de datos.\n"+
                    "Un ejemplo común de una estructura de datos recursiva es un árbol, donde cada nodo en el árbol puede tener cero o más hijos, que a su vez son nodos en el mismo árbol.\n"+
                    "Otro ejemplo de estructura de datos recursiva es una lista enlazada, donde cada elemento en la lista tiene un puntero al siguiente elemento en la lista, y el último elemento tiene un puntero nulo.\n"+
                    "El uso de estructuras de datos recursivas puede simplificar la implementación de algoritmos que operan en estas estructuras, ya que se pueden utilizar técnicas de programación recursiva. Por ejemplo, para procesar todos los nodos en un árbol, se puede utilizar una función recursiva que visite cada nodo y luego llame a sí misma para procesar los hijos de ese nodo.\n"+
                    "Sin embargo, el uso excesivo de estructuras de datos recursivas también puede llevar a problemas de desbordamiento de pila, especialmente en lenguajes de programación que no optimizan las llamadas recursivas mediante la eliminación de cola (tail-call optimization). Por lo tanto, se debe tener cuidado al diseñar y utilizar estructuras de datos recursivas.",
                    3: "Las estructuras de datos recursivas son aquellas estructuras que se definen en términos de sí mismas. En programación, las estructuras de datos recursivas se utilizan para representar datos que tienen una estructura jerárquica o de árbol, donde cada elemento puede tener uno o más elementos hijos que también pueden tener hijos propios, y así sucesivamente.\n"+
                    "Por ejemplo, una estructura de datos recursiva muy común es el árbol binario, donde cada nodo tiene hasta dos hijos, que a su vez pueden tener sus propios hijos. Otro ejemplo común es la lista enlazada, donde cada elemento de la lista tiene una referencia al siguiente elemento de la lista, formando una cadena de elementos.\n"+
                    "La ventaja de las estructuras de datos recursivas es que permiten una implementación eficiente de algoritmos que trabajan con datos jerárquicos, como la búsqueda, la inserción o el recorrido de los elementos en un árbol. Además, las estructuras de datos recursivas son muy flexibles y pueden adaptarse a una variedad de aplicaciones, lo que las hace muy útiles en programación."}
    
    Respuestas24 = {1: "Se prefiere a veces utilizar una tabla hash en lugar de una lista para la búsqueda de datos debido a su eficiencia en términos de tiempo de búsqueda. En una tabla hash, los elementos se almacenan en un arreglo y se accede a ellos a través de una función hash, que calcula la posición del elemento en el arreglo. Esta función de hash tiene como objetivo distribuir los elementos de forma uniforme en el arreglo, para que las búsquedas sean eficientes.\n"+
                    "En una lista, los elementos se almacenan de manera secuencial y se debe buscar uno por uno hasta encontrar el elemento deseado. Esto puede llevar mucho tiempo si la lista es muy grande.\n"+
                    "En una tabla hash, la búsqueda se realiza en tiempo constante O(1), ya que se utiliza la función hash para acceder directamente a la posición del elemento en el arreglo. Esto hace que la búsqueda sea muy eficiente, incluso para grandes conjuntos de datos.\n"+
                    "Sin embargo, la implementación de una tabla hash puede ser más compleja que la de una lista, ya que se debe definir una función hash adecuada y manejar posibles colisiones que puedan ocurrir cuando varios elementos tienen la misma posición en el arreglo. Además, la tabla hash puede ser menos eficiente en términos de uso de memoria que una lista simple.",
                    2: "La elección entre una tabla hash y una lista para la búsqueda de datos depende del contexto y los requisitos específicos de la aplicación. Sin embargo, en general, se prefiere utilizar una tabla hash en lugar de una lista para la búsqueda de datos en los siguientes casos:\n"+
                    "-> Búsqueda eficiente: las tablas hash permiten una búsqueda eficiente en promedio con una complejidad de tiempo constante O(1), mientras que en una lista la búsqueda requiere una comparación secuencial de cada elemento en la lista, lo que lleva una complejidad de tiempo lineal O(n).\n"+
                    "-> Conjunto de datos grande: cuando se manejan conjuntos de datos grandes, la complejidad de búsqueda lineal de una lista puede ser prohibitivamente costosa en términos de tiempo y recursos de memoria\n"+
                    "-> Búsqueda con claves complejas: en algunos casos, las claves de búsqueda pueden ser complejas, como cadenas de texto largas o objetos grandes, y la tabla hash permite una búsqueda eficiente en promedio sin necesidad de comparar las claves directamente.\n" +
                    "Sin embargo, es importante tener en cuenta que las tablas hash tienen algunas desventajas en comparación con las listas, como la posibilidad de colisiones, que pueden afectar el rendimiento de la búsqueda. Además, la implementación de una tabla hash puede requerir más recursos de memoria que una lista debido a la necesidad de mantener una tabla hash y los datos asociados.",
                    3: "A menudo, se prefiere utilizar una tabla hash en lugar de una lista para la búsqueda de datos debido a que las tablas hash pueden proporcionar un acceso más rápido a los datos. Esto se debe a que la tabla hash utiliza una función hash para asignar una clave a una posición en la tabla, en lugar de buscar la clave en una lista secuencialmente.\n"+
                    "Por lo tanto, cuando se busca un elemento en una tabla hash, la función hash se aplica a la clave del elemento y se utiliza para determinar la posición en la tabla donde se encuentra el elemento correspondiente. En comparación con una búsqueda lineal en una lista, la búsqueda en una tabla hash puede ser mucho más rápida para grandes conjuntos de datos.\n"+
                    "Además, las tablas hash también pueden proporcionar una inserción y eliminación eficiente de elementos, ya que la función hash también puede ser utilizada para determinar la posición donde se inserta o elimina un elemento de la tabla.\n"+
                    "Sin embargo, también es importante tener en cuenta que el rendimiento de una tabla hash puede verse afectado por la calidad de la función hash utilizada, así como por la cantidad de colisiones que se producen en la tabla. En algunos casos, una lista secuencial puede ser más adecuada para la búsqueda de datos, especialmente si el conjunto de datos es pequeño y los elementos se encuentran en una secuencia lógica y ordenada."}
    
    Respuestas25 = {1: "En la mayoría de los lenguajes de programación, puedes crear un arreglo de la siguiente manera:\n"+
                    "1. Primero, debes declarar el arreglo, indicando su tamaño (la cantidad de elementos que contendrá) y el tipo de datos que contendrá. Por ejemplo, si deseas crear un arreglo de enteros de tamaño 5, en Java podrías hacer lo siguiente:\nint[] arreglo = new int[5];\n"+
                    "2. Luego, puedes asignar valores a cada uno de los elementos del arreglo. Por ejemplo, para asignar el valor 10 al primer elemento del arreglo, podrías hacer lo siguiente:\narreglo[0] = 10;\n"+
                    "3. 3.	También puedes inicializar el arreglo con valores predefinidos en la declaración. Por ejemplo, si deseas crear un arreglo de enteros de tamaño 3 y asignar los valores 1, 2 y 3 a cada uno de sus elementos, puedes hacer lo siguiente:\nint[] arreglo = {1, 2, 3};\n"+
                    "En otros lenguajes de programación, como Python, la sintaxis para crear un arreglo es         un poco diferente. Por ejemplo, en Python, un arreglo se llama \"lista\" y se puede crear de la siguiente manera:\n"+
                    "arreglo = [1, 2, 3, 4, 5]\n"+
                    "En general, la sintaxis para crear un arreglo varía según el lenguaje de programación utilizado, pero los pasos básicos son declarar el tamaño y el tipo de datos del arreglo, asignar valores a cada uno de sus elementos y, opcionalmente, inicializar el arreglo con valores predefinidos."}
    
    Respuestas26 = {1: "Para crear una lista enlazada en programación, primero necesitas definir una clase que represente un nodo de la lista. Cada nodo tendrá un valor y una referencia al siguiente nodo en la lista. Aquí hay un ejemplo en Python:\n"+
                    "class Nodo:\n"+
                    "\tdef __init__(self, valor):\n"+
                    "\t\t  self.valor = valor\n"+
                    "\t\t  self.siguiente = None\n"+
                    "Una vez que tienes la clase Nodo, puedes utilizarla para construir la lista enlazada. La lista enlazada está formada por una serie de nodos conectados entre sí mediante la referencia siguiente. El primer nodo se llama \"cabeza\" y el último nodo se llama \"cola\". Aquí hay un ejemplo de cómo crear una lista enlazada que contiene los números del 1 al 5:\n"+
                    "# Creamos el primer nodo de la lista\n"+
                    "cabeza = Nodo(1)\n"+
                    "\n# Creamos los nodos restantes y los enlazamos\n"
                    "nodo2 = Nodo(2)\n"+
                    "cabeza.siguiente = nodo2\n"+
                    "\nnodo3 = Nodo(3)\n"+
                    "nodo2.siguiente = nodo3\n"+
                    "\nnodo4 = Nodo(4)\n"+
                    "nodo3.siguiente = nodo4\n"+                
                    "\nnodo5 = Nodo(5)\n"+
                    "nodo4.siguiente = nodo5\n"+                
                    "\n# La cola de la lista es el último nodo\n"+
                    "cola = nodo5\n"+
                    "\nEn Java, para crear una lista enlazada, primero necesitas definir una clase que represente un nodo de la lista. Cada nodo tendrá un valor y una referencia al siguiente nodo en la lista. Aquí hay un ejemplo:\n"+
                    "public class Nodo {\n"+
                        "\tint valor;\n"+
                        "\tNodo siguiente;\n"+
                    
                        "\n\tpublic Nodo(int valor) {\n"+
                            "\t\tthis.valor = valor;\n"+
                            "\t\tthis.siguiente = null;\n"+
                        """\t}"""
                    """}"""+
                    "Una vez que tienes la clase Nodo, puedes utilizarla para construir la lista enlazada. La lista enlazada está formada por una serie de nodos conectados entre sí mediante la referencia siguiente. El primer nodo se llama \"cabeza\" y el último nodo se llama \"cola\". Aquí hay un ejemplo de cómo crear una lista enlazada que contiene los números del 1 al 5:"+
                    "// Creamos el primer nodo de la lista\n"+
                    "Nodo cabeza = new Nodo(1);\n\n"+                
                    "// Creamos los nodos restantes y los enlazamos\n"+
                    "Nodo nodo2 = new Nodo(2);\n"+
                    "cabeza.siguiente = nodo2;\n\n"+                
                    "Nodo nodo3 = new Nodo(3);\n"+
                    "nodo2.siguiente = nodo3;\n\n"+               
                    "Nodo nodo4 = new Nodo(4);\n"+
                    "nodo3.siguiente = nodo4;\n"+               
                    "Nodo nodo5 = new Nodo(5);\n"+
                    "nodo4.siguiente = nodo5;\n\n"+                
                    "// La cola de la lista es el último nodo\n"+
                    "Nodo cola = nodo5;\n"+
                    "En este ejemplo, creamos el primer nodo (la cabeza) y luego creamos los nodos restantes y los enlazamos mediante la referencia siguiente. La cola de la lista es el último nodo. Puedes acceder a los elementos de la lista enlazada recorriendo los nodos a partir de la cabeza y siguiendo las referencias siguiente."}
    
    Respuestas27 = {1: "En programación, una pila es una estructura de datos que sigue el principio LIFO (Last In, First Out), lo que significa que el último elemento agregado a la pila es el primero en salir. Para crear una pila en programación, puedes utilizar un arreglo o una lista enlazada. Aquí te presento un ejemplo de cómo crear una pila con una lista enlazada en Java:\n"+
                    "public class Pila {\n"
                    "Nodo cabeza;\n"
                
                    """public Pila() {
                        cabeza = null;
                    }
                
                    public void push(int valor) {
                        Nodo nuevoNodo = new Nodo(valor);
                        nuevoNodo.siguiente = cabeza;
                        cabeza = nuevoNodo;
                    }
                
                    public int pop() {
                        if (cabeza == null) {
                            throw new NoSuchElementException();
                        }
                        int valor = cabeza.valor;
                        cabeza = cabeza.siguiente;
                        return valor;
                    }
                
                    public boolean estaVacia() {
                        return cabeza == null;
                    }
                    }"""+
                    "En este ejemplo, creamos una clase Pila que contiene una referencia a la cabeza de la lista enlazada (cabeza). La pila se inicializa como vacía en el constructor (cabeza = null). La operación push agrega un nuevo elemento a la pila creando un nuevo nodo y estableciendo su referencia siguiente en la cabeza actual de la pila. La nueva cabeza de la pila se actualiza para ser el nuevo nodo. La operación pop elimina el elemento superior de la pila y devuelve su valor. Si la pila está vacía, se lanza una excepción. La operación estaVacia devuelve true si la pila está vacía y false en caso contrario.\n"+
                    "En Python, puedes crear una pila utilizando una lista ya que las listas en Python tienen métodos que permiten emular una pila. Aquí te presento un ejemplo de cómo crear una pila en Python utilizando una lista:\n"+
                    "class Pila:\n"
                    """def __init__(self):
                        self.items = []
                
                    def push(self, item):
                        self.items.append(item)
                
                    def pop(self):
                        if not self.esta_vacia():
                            return self.items.pop()
                        else:
                            raise Exception('La pila está vacía')
                
                    def esta_vacia(self):
                        return len(self.items) == 0"""+
                    "En este ejemplo, creamos una clase Pila que inicializa una lista vacía en el constructor (__init__). La operación push agrega un elemento a la pila utilizando el método append de la lista. La operación pop elimina el elemento superior de la pila y devuelve su valor utilizando el método pop de la lista. Si la pila está vacía, se lanza una excepción. La operación esta_vacia devuelve True si la pila está vacía y False en caso contrario."}
            
    
    Respuestas28 = {1: "Para crear una cola en programación, podemos utilizar una lista en la que agregaremos los elementos en un extremo (el final de la lista) y eliminaremos los elementos por el otro extremo (el principio de la lista). Aquí te presento un ejemplo en Python de cómo crear una cola utilizando una lista:\n"+
                    """class Cola:
                    def __init__(self):
                        self.items = []
                
                    def encolar(self, item):
                        self.items.append(item)
                
                    def desencolar(self):
                        if not self.esta_vacia():
                            return self.items.pop(0)
                        else:
                            raise Exception('La cola está vacía')
                
                    def esta_vacia(self):
                        return len(self.items) == 0"""+
                    "En este ejemplo, creamos una clase Cola que inicializa una lista vacía en el constructor (__init__). La operación encolar agrega un elemento a la cola utilizando el método append de la lista. La operación desencolar elimina el elemento más antiguo de la cola y devuelve su valor utilizando el método pop de la lista con el índice 0 (que es el primer elemento de la lista). Si la cola está vacía, se lanza una excepción. La operación esta_vacia devuelve True si la cola está vacía y False en caso contrario.\n"+
                    "\nEn Java, también podemos crear una cola utilizando una lista, pero es más común utilizar la interfaz Queue que proporciona la biblioteca estándar de Java. Aquí te presento un ejemplo de cómo crear una cola utilizando LinkedList (una implementación de la interfaz List que también implementa la interfaz Queue):\n"+
                    """import java.util.LinkedList;
                    import java.util.Queue;
                    
                    public class Cola {
                        public static void main(String[] args) {
                            Queue<String> cola = new LinkedList<>();
                            
                            // Encolar elementos
                            cola.add("Juan");
                            cola.add("María");
                            cola.add("Pedro");
                            
                            // Desencolar elementos
                            String primero = cola.remove();
                            String segundo = cola.remove();
                            String tercero = cola.remove();
                            
                            // Imprimir elementos
                            System.out.println("Elementos desencolados: " + primero + ", " + segundo + ", " + tercero);
                        }
                    }"""+
                    "En este ejemplo, creamos una instancia de LinkedList y la asignamos a una variable de tipo Queue. La operación add agrega un elemento a la cola y la operación remove elimina y devuelve el elemento más antiguo de la cola. Si la cola está vacía, se lanza una excepción. Podemos utilizar el método peek para obtener el elemento más antiguo de la cola sin eliminarlo."}
        
    
    Respuestas29 = {1: "En programación, un árbol se puede crear utilizando una estructura de datos que tenga un puntero o referencia a un conjunto de otras estructuras de datos. A continuación, te presento un ejemplo de cómo crear un árbol binario en Java utilizando una clase que representa los nodos del árbol:\n"+
                    """public class NodoArbol {
                        int valor;
                        NodoArbol izquierdo, derecho;
                     
                        public NodoArbol(int valor) {
                            this.valor = valor;
                            izquierdo = derecho = null;
                        }
                    }"""+
                    "En este ejemplo, la clase NodoArbol tiene tres atributos: un entero valor que representa el valor del nodo y dos referencias a otros nodos izquierdo y derecho que representan los hijos izquierdo y derecho del nodo, respectivamente.\n"+
                    "Para construir un árbol, necesitamos crear una instancia de la clase NodoArbol para cada nodo y establecer las referencias entre ellos. Aquí te presento un ejemplo de cómo crear un árbol binario con valores arbitrarios:\n"+
                    """public class ArbolBinario {
                        NodoArbol raiz;
                    
                        public ArbolBinario() {
                            raiz = null;
                        }
                    
                        public void insertar(int valor) {
                            raiz = insertarRec(raiz, valor);
                        }
                        
                        private NodoArbol insertarRec(NodoArbol nodo, int valor) {
                            if (nodo == null) {
                                nodo = new NodoArbol(valor);
                                return nodo;
                            }
                     
                            if (valor < nodo.valor)
                                nodo.izquierdo = insertarRec(nodo.izquierdo, valor);
                            else if (valor > nodo.valor)
                                nodo.derecho = insertarRec(nodo.derecho, valor);
                     
                            return nodo;
                        }
                    
                        public static void main(String[] args) {
                            ArbolBinario arbol = new ArbolBinario();
                            arbol.insertar(50);
                            arbol.insertar(30);
                            arbol.insertar(20);
                            arbol.insertar(40);
                            arbol.insertar(70);
                            arbol.insertar(60);
                            arbol.insertar(80);
                        }
                    }""" +
                    "En este ejemplo, creamos una instancia de la clase ArbolBinario y llamamos al método insertar para agregar valores al árbol. La operación de inserción es recursiva y utiliza el método insertarRec para buscar la posición adecuada para el nuevo nodo en el árbol. La raíz del árbol se establece en la primera inserción y se actualiza cada vez que se agrega un nuevo nodo.\n"
                    "En Python, se puede crear un árbol utilizando clases y objetos. Por ejemplo, se puede definir una clase Nodo que tenga atributos para almacenar su valor y sus nodos hijos (izquierdo y derecho), y luego construir el árbol mediante la creación de instancias de esta clase y estableciendo sus relaciones entre nodos.\n"
                    "Aquí hay un ejemplo de cómo se puede crear un árbol binario en Python:\n"+
                    """class Nodo:
                        def __init__(self, valor):
                            self.valor = valor
                            self.izquierdo = None
                            self.derecho = None
    
                        nodo1 = Nodo(1)
                        nodo2 = Nodo(2)
                        nodo3 = Nodo(3)
                        nodo4 = Nodo(4)
                        nodo5 = Nodo(5)
                        
                        # Construir el árbol
                        nodo1.izquierdo = nodo2
                        nodo1.derecho = nodo3
                        nodo2.izquierdo = nodo4
                        nodo2.derecho = nodo5"""+
                        "En este ejemplo, se define la clase Nodo con un constructor que inicializa los atributos valor, izquierdo y derecho en None. Luego, se crean cinco nodos y se establecen las relaciones entre ellos para construir el árbol.\n"}
        
    Respuestas30 = {1: """En programación, se puede crear un grafo utilizando una representación de matriz de adyacencia o una lista de adyacencia.
                        Una representación de matriz de adyacencia utiliza una matriz bidimensional para representar los nodos y las aristas del grafo. Cada elemento de la matriz representa una posible conexión entre dos nodos, y se puede marcar como "1" si existe una conexión y "0" si no existe. Aquí hay un ejemplo de cómo se puede crear un grafo utilizando una representación de matriz de adyacencia en Python:
                        # Crear una matriz de adyacencia para un grafo no dirigido con 4 nodos
                        grafo = [
                            [0, 1, 0, 1],
                            [1, 0, 1, 0],
                            [0, 1, 0, 1],
                            [1, 0, 1, 0]
                        ]
                        En este ejemplo, se define una matriz grafo con cuatro filas y cuatro columnas, que representa un grafo no dirigido con cuatro nodos. Las conexiones entre los nodos se establecen mediante la asignación de "1" a los elementos de la matriz que representan una conexión.
                        Una lista de adyacencia, por otro lado, es una lista de listas que representa cada nodo y sus conexiones con otros nodos. Cada elemento de la lista de adyacencia representa un nodo y contiene una lista de sus nodos adyacentes. Aquí hay un ejemplo de cómo se puede crear un grafo utilizando una lista de adyacencia en Python:
                        # Crear una lista de adyacencia para un grafo no dirigido con 4 nodos
                        grafo = [
                            [1, 3],
                            [0, 2],
                            [1, 3],
                            [0, 2]
                        ]
                        En este ejemplo, se define una lista grafo con cuatro elementos, que representan los cuatro nodos del grafo. Cada elemento de la lista contiene otra lista que representa los nodos adyacentes a ese nodo en el grafo.
                        Una vez que se ha creado el grafo, se pueden realizar diversas operaciones sobre él, como búsqueda en profundidad o búsqueda en amplitud para recorrer los nodos del grafo y encontrar caminos entre ellos.
                        
                        Para crear un grafo en Java, se pueden seguir los siguientes pasos:
                        1.	Definir una clase Graph que contendrá una lista de adyacencia para representar las relaciones entre los nodos del grafo. La lista de adyacencia se puede implementar utilizando una HashMap, donde las claves son los nodos del grafo y los valores son una lista de nodos adyacentes.
                        2.	Implementar métodos para agregar nodos al grafo y para agregar relaciones entre los nodos.
                        3.	Implementar un método para recorrer el grafo utilizando el algoritmo de búsqueda en profundidad (DFS) o búsqueda en anchura (BFS).
                        4.	Opcionalmente, se pueden agregar métodos para eliminar nodos y relaciones del grafo, y para encontrar rutas entre dos nodos.
                        A continuación, se muestra un ejemplo de cómo crear un grafo en Java utilizando una lista de adyacencia implementada con una HashMap:
                        import java.util.*;
                        
                        class Graph {
                            private Map<Integer, List<Integer>> adjacencyList;
                        
                            public Graph() {
                                adjacencyList = new HashMap<>();
                            }
                        
                            public void addNode(int node) {
                                adjacencyList.put(node, new LinkedList<>());
                            }
                        
                            public void addEdge(int node1, int node2) {
                                adjacencyList.get(node1).add(node2);
                                adjacencyList.get(node2).add(node1);
                            }
                        
                            public void dfs(int startNode) {
                                Set<Integer> visited = new HashSet<>();
                                dfsHelper(startNode, visited);
                            }
                        
                            private void dfsHelper(int node, Set<Integer> visited) {
                                visited.add(node);
                                System.out.print(node + " ");
                        
                                List<Integer> neighbors = adjacencyList.get(node);
                                for (int neighbor : neighbors) {
                                    if (!visited.contains(neighbor)) {
                                        dfsHelper(neighbor, visited);
                                    }
                                }
                            }
                        }
                        
                        public class Main {
                            public static void main(String[] args) {
                                Graph g = new Graph();
                        
                                g.addNode(0);
                                g.addNode(1);
                                g.addNode(2);
                                g.addNode(3);
                        
                                g.addEdge(0, 1);
                                g.addEdge(0, 2);
                                g.addEdge(1, 2);
                                g.addEdge(2, 3);
                        
                                System.out.println("DFS traversal:");
                                g.dfs(0);
                            }
                        }
                        En este ejemplo, se crea un grafo con cuatro nodos y cuatro relaciones. Luego, se llama al método dfs para recorrer el grafo utilizando el algoritmo de búsqueda en profundidad. La salida del programa será:
                        DFS traversal:
                        0 1 2 3"""}
    
    
    Respuestas31 = {1: """Para crear una tabla hash en programación, es necesario seguir los siguientes pasos:
                        1.	Definir la estructura de la tabla hash: se debe decidir el tamaño de la tabla y cómo se van a almacenar los datos, por ejemplo, si se van a usar listas enlazadas o arreglos para resolver colisiones.
                        2.	Crear la función hash: esta función es la encargada de transformar la clave del elemento a insertar en un índice en la tabla hash.
                        3.	Crear la tabla hash: se puede crear una tabla hash como un arreglo o una lista de elementos, dependiendo de la implementación elegida en el primer paso.
                        4.	Insertar elementos: para insertar un elemento en la tabla hash, se debe aplicar la función hash a la clave del elemento para obtener su posición en la tabla, y luego se inserta el elemento en esa posición.
                        5.	Buscar elementos: para buscar un elemento en la tabla hash, se aplica la función hash a la clave del elemento para obtener su posición en la tabla, y luego se busca el elemento en esa posición. Si hay colisiones, se deben resolver de acuerdo a la implementación elegida en el primer paso.
                        6.	Eliminar elementos: para eliminar un elemento de la tabla hash, se busca su posición en la tabla aplicando la función hash a su clave, y luego se elimina el elemento de esa posición.
                        A continuación, se presenta un ejemplo de cómo crear una tabla hash en Python utilizando listas enlazadas para resolver colisiones:
                        class Node:
                            def __init__(self, key, value):
                                self.key = key
                                self.value = value
                                self.next = None
                        
                        class HashTable:
                            def __init__(self, size):
                                self.size = size
                                self.table = [None] * size
                        
                            def hash(self, key):
                                return hash(key) % self.size
                        
                            def insert(self, key, value):
                                index = self.hash(key)
                                node = self.table[index]
                                while node is not None and node.key != key:
                                    node = node.next
                                if node is None:
                                    node = Node(key, value)
                                    node.next = self.table[index]
                                    self.table[index] = node
                                else:
                                    node.value = value
                        
                            def search(self, key):
                                index = self.hash(key)
                                node = self.table[index]
                                while node is not None and node.key != key:
                                    node = node.next
                                if node is None:
                                    return None
                                else:
                                    return node.value
                        
                            def delete(self, key):
                                index = self.hash(key)
                                node = self.table[index]
                                prev = None
                                while node is not None and node.key != key:
                                    prev = node
                                    node = node.next
                                if node is not None:
                                    if prev is None:
                                        self.table[index] = node.next
                                    else:
                                        prev.next = node.next
                        En este ejemplo, la clase Node representa un nodo de la lista enlazada utilizada para resolver colisiones, y la clase HashTable representa la tabla hash. La función hash utiliza la función hash de Python para transformar la clave del elemento en un índice en la tabla, y la función insert inserta un elemento en la tabla. La función search busca un elemento en la tabla, y la función delete elimina un elemento de la tabla.
                        
                        En Java, se puede crear una tabla hash utilizando la clase HashMap. Aquí hay un ejemplo básico de cómo crear y utilizar una tabla hash en Java:
                        import java.util.HashMap;
                        
                        public class EjemploTablaHash {
                            public static void main(String[] args) {
                                // Crear una tabla hash vacía
                                HashMap<String, Integer> tabla = new HashMap<>();
                        
                                // Agregar elementos a la tabla hash
                                tabla.put("Juan", 25);
                                tabla.put("María", 30);
                                tabla.put("Pedro", 20);
                        
                                // Acceder a un elemento de la tabla hash
                                System.out.println("La edad de María es " + tabla.get("María"));
                        
                                // Eliminar un elemento de la tabla hash
                                tabla.remove("Pedro");
                        
                                // Iterar sobre la tabla hash
                                for (String nombre : tabla.keySet()) {
                                    System.out.println(nombre + " tiene " + tabla.get(nombre) + " años.");
                                }
                            }
                        }
                        En este ejemplo, se crea una tabla hash vacía utilizando la clase HashMap. La tabla hash tiene claves de tipo String y valores de tipo Integer. Se agregan elementos a la tabla hash utilizando el método put(), se accede a un elemento utilizando el método get(), se elimina un elemento utilizando el método remove() y se itera sobre la tabla hash utilizando un bucle for y los métodos keySet() y get()."""}
    
    def __init__(self):
        """Constructor"""
        
    def __del__(self):
        """Destructor"""
        print("Destruyendo respuestas")

    def __str__(self):
        """Devuelve descripcion de clase"""
        cad = "Respuestas de 31 preguntas sobre estructuras de datos"
        return cad


